<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>n</span>ews</h2>
                <h3 class="jp-ttl">ベストゼミナールからのお知らせ</h3>
            </div>
            <div class="sl-subpage-list">
                    <ul>
                        <li><a href="#">模擬試験</a></li>
                        <li><a href="#">教育セミナートップ</a></li>
                        <li><a href="#">入試実績</a></li>
                        <li><a href="#">子供新聞</a></li>
                        <li><a href="#">Facebook</a></li>
                        <li><a href="#">Blog</a></li>
                    </ul>
            </div>
        </div>
        <div class="sl-subpage-news-inn inner">
            <div class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-news-inn-content">
                <div class="sl-subpage-news-inn-content-ttl hd-underline">
                    <h2>お知らせ一覧</h2>
                </div>
                <div class="sl-subpage-news-inn-content-box box-shadow">
                    <div class="box-data">
                    <?php if ( have_posts() ) : ?>
                        <?php
                        while ( have_posts() ) :
                            the_post();
                            get_template_part( 'template-parts/content-news', get_post_type() );

                        endwhile;

                        endif;
                        ?>  
                    </div>
                </div>
                
                <div class="moreBtn">
                    <a href="#">more</a>
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();
