<article>
    <a href="<?php the_permalink(); ?>" class="course-info">
        <figure><?php echo get_the_post_thumbnail(); ?></figure>
    <h3><span><?php the_title(); ?></span></h3>
    </a>
</article>