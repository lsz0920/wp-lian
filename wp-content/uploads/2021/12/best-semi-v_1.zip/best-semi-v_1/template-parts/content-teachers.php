<article class="box-shadow">
    <figure>
        <?php echo get_the_post_thumbnail(); ?>
    </figure>
    <h3><?php the_title(); ?></h3>
        <?php
            $post_tags = get_the_terms( $post->ID , 'teacher_tag' );
            if ( $post_tags ) {
        ?>
        <p class="tag">
            <?php 
                foreach ($post_tags as $tag) {
                $tag_link = get_tag_link( $tag->term_id );
            ?>
            <span><?php echo $tag->name; ?></span>
            <?php } ?>
        </p>
    <?php } ?>
    <?php the_content(); ?>
</article>