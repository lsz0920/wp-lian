<article>
    <h4><?php the_title(); ?></h4>
    <figure>
        <?php echo get_the_post_thumbnail(); ?>
    </figure>
    <small><?php the_time('Y年 m月') ?></small>
</article>