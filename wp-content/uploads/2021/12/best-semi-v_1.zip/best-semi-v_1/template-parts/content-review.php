<article class="box-shadow d-fl">
    <div class="item-img">
        <figure>
            <?php echo get_the_post_thumbnail(); ?>
        </figure>
    </div>
    <div class="item-info">
        <div class="item-info-ttl d-fl">
            <h3><?php the_title();?><?php if(CFS()->get('place')): ?><span><?php echo CFS()->get('place'); ?></span><?php endif; ?></h3>
            <span>投稿日<time><?php the_time('Y 年 m 月 d 日'); ?></time></span>
        </div>
        <div class="item-info-data">
            <?php the_content(); ?>
        </div>
    </div>
</article>