<article class="data-item-box box-shadow d-fl">
    <div class="box-img">
        <?php echo get_the_post_thumbnail(); ?>
    </div>
    <div class="box-detail">
        <span class="date"><?php the_time('Y.m.d'); ?></span>
        <h3><?php the_title(); ?></h3>
        <?php the_excerpt(); ?>
        <span class="more"><a href="<?php the_permalink(); ?>">more</a></span>
    </div>
</article>