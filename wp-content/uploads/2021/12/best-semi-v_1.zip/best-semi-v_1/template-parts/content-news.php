<a href="<?php the_permalink(); ?>">
    <dl>
        <dt><?php the_time('Y.m.d'); ?></dt>
        <dd><?php the_title(); ?></dd>
    </dl>
</a>