<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

	<main id="primary" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>R</span>EASON</h2>
                <h3 class="jp-ttl">スクールの特長</h3>
            </div>
            <div class="sl-subpage-list">
                <ul>
                    <li><a href="#">模擬試験</a></li>
                    <li><a href="#">教育セミナートップ</a></li>
                    <li><a href="#">入試実績</a></li>
                    <li><a href="#">子供新聞</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </div>
        </div>
        <div class="sl-reason">
            <div class="sl-reason-inn">
                <div class="breadcrumbs inner" typeof="BreadcrumbList" vocab="http://schema.org/">
                    <?php if (function_exists('bcn_display')) {
                            bcn_display();
                    }?>
                </div>
                <div class="sl-reason-inn-content">
                    <div class="point-wrap">
                        <div class="point-inn">
                            <div class="point-detail d-fl">
                                <div class="point-img">
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/reason/reason-01.png" alt="reason image">
                                    </figure>
                                </div>
                                <div class="point-text">
                                    <span class="point-number">POINT 01</span>
                                    <h4><span>マンツーマン授業</span></h4>
                                    <p>
                                        ベストゼミナールの授業は、全てマンツーマンで行っています。<br>
                                        学校でのクラス授業ですと、どうしても先生の話す時間が長くなり受け身になりがちですが、マンツーマンで行うことにより、日本語を聞いて自分で答えなくてはならないという意識になり、特に言語学習として、日本語の向上につながります。<br>
                                        また、国語、算数等教科についても、生徒のわからないところをわかるまで指導していきます。<br>
                                        だから生徒それぞれに合わせたレベルの学習を効率的に進めることができます。
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="point-inn">
                            <div class="point-detail d-fl">
                                <div class="point-img">
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/reason/reason-02.png" alt="reason image">
                                    </figure>
                                </div>
                                <div class="point-text">
                                    <span class="point-number">POINT 02</span>
                                    <h4><span>担任制による信頼の授業</span></h4>
                                    <p>
                                    ベストゼミナールでは、完全担任制をとっています。毎回同じ先生だから、生徒との信頼関係を築きながら二人三脚で授業を進めます。<br>
                                    だからこそ、講師は、生徒の得意分野や苦手なところを正確に把握して、何をすべきか明確にできるのです。<br>
                                    特に受験指導や、言語教育の場合、毎回決まった先生が行うことにより、目標に沿った、継続的な学習指導を行うことができます。<br>そのように、一人ひとりにカスタマイズされた学習メニューや、きめ細かなフォローが生徒の「やる気」を引き出し、「できる」を実感させます。<br>
                                    「自分のことを、親身に考えてくれる先生がいる」それが、生徒の揺るぎない自信になり、真の実力につながってくるのです。
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="point-inn">
                            <div class="point-detail d-fl">
                                <div class="point-img">
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/reason/reason-03.png" alt="reason image">
                                    </figure>
                                    <div class="point-btn">
                                        <a href="<?php echo esc_html( home_url('/') ) ?>" class="btn01">講師紹介</a>
                                        <a href="<?php echo esc_html( home_url('/') ) ?>" class="btn02">講師勉強会</a>
                                    </div>
                                </div>
                                <div class="point-text">
                                    <span class="point-number">POINT 03</span>
                                    <h4><span>熱意のあるプロの講師陣</span></h4>
                                    <p>
                                        ベストゼミナールの講師は、ベストゼミナールだから教えたいという講師です。<br>
                                        「海外にいるお子様に教えたい」という熱烈な想いがあるからこそ、こだわった授業となります。<br>
                                        その一つが、講師の勉強会です。<br>
                                        月に数回、ベストゼミナール講師間で勉強会もおこなっており、授業への集中力の持続や日本語の苦手なお子様への効果的な発話の促し方、フリートークの展開など、レッスンのクオリティをあげるため常に尽力しています。<br>
                                        たとえば「インターネットのゲームを使おう」「絵本を使おう」「手づくり教材を作ってみよう」「カタカナや漢字を覚えるのにお子様の好きなキャラクターを使おう」等経験に基づいたアイデアを出し合って講師間で共有し、それぞれの授業に活かしています。<br>
                                        また、ベストゼミナールの講師は、日本語教師、教員免許取得者、元小中学校の教員経験者、進学塾講師経験者のいずれかであり、教育に関するプロフェッショナルが授業を担当します。
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="point-inn">
                            <div class="point-detail d-fl">
                                <div class="point-img">
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/reason/reason-04.png" alt="reason image">
                                    </figure>
                                    <div class="point-btn">
                                        <a href="<?php echo esc_html( home_url('/') ) ?>" class="btn01">合格者実績</a>
                                        <a href="<?php echo esc_html( home_url('/') ) ?>" class="btn02 white-btn">教育セミナー</a>
                                    </div>
                                </div>
                                <div class="point-text">
                                    <span class="point-number">POINT 04</span>
                                    <h4><span>設立から16年間の経験</span></h4>
                                    <p>
                                    ベストゼミナールは、こどもの日本語教育、帰国生受験に携わってきたスペシャリストとして16年間の経験があります。経験があるということは、日本語資格取得や受験合格といったゴールに到達するための方法を熟知しているということです。<br><br>
                                    ＜こどもの日本語教育＞<br>
                                    当初は手探りではありましたが、現在では、帰国生受験に成功した多くのベストゼミナール卒業生のデータや講師の経験則をもとに、授業の進め方、教材の選定、教材の作り方などの具体的な方法を確立するに至りました。<br>
                                    また、毎月の講師勉強会を通じ、常に講師間で情報交換をしながら、少しでも生徒が楽しく、効率的に結果に結びつけられる日本語学習ができるよう日々改善を重ねております。<br><br>
                                    ＜帰国子女入試＞<br>
                                    ベストゼミナールでは、これまでに数百もの帰国子女入試に取り組んでまいりました。実際に80校を超える学校訪問をし、帰国生担当の先生方とお話しするなかで、入試の傾向、面接の観点、各校が求める生徒像を理解して情報を蓄積してきました。<br>その経験をもとに、お子様ひとりひとりにあわせた勉強法をご提案いたします。確実に学力が上がるやり方で受験にチャレンジしてください。
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>     
    </div>
    <?php get_template_part('common-banner');?>
	</main><!-- #main -->

<?php
get_footer();
