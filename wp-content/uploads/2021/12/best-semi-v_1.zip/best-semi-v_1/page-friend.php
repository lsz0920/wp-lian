<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>f</span>riend</h2>
                <h3 class="jp-ttl">友割キャンペーン</h3>
            </div>
            <div class="sl-subpage-list">
                <ul>
                    <li><a href="#">模擬試験</a></li>
                    <li><a href="#">教育セミナートップ</a></li>
                    <li><a href="#">入試実績</a></li>
                    <li><a href="#">子供新聞</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </div>
        </div>
        <div class="sl-subpage-friend-inn">
            <div class="breadcrumbs inner" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-friend-inn-content">
                <div class="sl-subpage-friend-inn-content-box">
                    <div class="box-ttl">
                        <h2>お友達紹介キャンペーン</h2>
                    </div>
                    <div class="box-data">
                        <div class="box-data-mv">
                            <figure>
                                <img src="<?php echo get_template_directory_uri(); ?>/img/friend/friend-mv.jpg" alt="">
                            </figure>
                            <h2>
                                <img src="<?php echo get_template_directory_uri(); ?>/img/friend/notic-txt.svg" alt="">
                            </h2>
                            <span>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/friend/price.svg" alt="">
                                </figure>
                            </span>
                        </div>
                        <div class="box-data-ttl">
                            <h2><span>概 要</span></h2>
                        </div>
                        <div class="box-data-content">
                            <table>
                                <tr>
                                    <th><span>期　間</span></th>
                                    <td>2021年00月00日 ～ 2021年00月00日</td>
                                </tr>
                                <tr>
                                    <th><span>対象者</span></th>
                                    <td>ベストゼミナールの無料体験授業を受けていただき、1ヵ月間の無料体験を完遂した方が対象となります。<br>
                                    （無料体験の途中で辞めてしまった場合は、対象外とさせていただきます。）</td>
                                </tr>
                                <tr>
                                    <th><span>メリット</span></th>
                                    <td>１．ご紹介者の翌月分授業料が＄50割引 <br>
                                        ２．新規会員の初月分授業料が＄50割引</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-friend-inn-content-box">
                    <div class="box-ttl">
                        <h2>お友達紹介キャンペーン</h2>
                    </div>
                    <div class="box-data">
                        <div class="box-data-content">
                            <div class="box-data-content-list d-fl">
                                <div class="content-img">
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/friend/img01.png" alt="">
                                    </figure>
                                </div>
                                <div class="content-info">
                                    <div class="box-data-ttl">
                                        <h3><span>日本語での勉強を<br>
                                        共感し合える仲間ができる</span>
                                    </h3>
                                    </div>
                                    <p>
                                        ベストゼミでの勉強について共感し合ったり、競い合ったり、そんな仲間がいれば、勉強がもっと楽しく、もっと豊かな体験になるでしょう。<br>
                                        同じ目標を持ち、助け合うことができる友達の存在は、お子様の勉強の大きな心の支えとなります。
                                    </p>
                                </div>
                            </div>
                            <div class="box-data-content-list d-fl">
                                <div class="content-img">
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/friend/img02.png" alt="">
                                    </figure>
                                </div>
                                <div class="content-info">
                                    <div class="box-data-ttl">
                                        <h3><span>日本語を通じて <br>
                                            更なる友情を築く</span>
                                        </h3>
                                    </div>
                                    <p>
                                        「今週のレッスン、どうだった？」、
                                        「今どんなことやってるの？」。 <br>
                                        ベストゼミの授業の話題が、目標を共有する貴重なお友達との新しい関係を築くきっかけとなるかもしれません。
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-friend-inn-content-box">
                    <div class="box-ttl">
                        <h2>お申込み方法</h2>
                    </div>
                    <div class="box-data-content">
                        <div class="box-data-content-info">
                            <p>下のお申込みフォームよりお申し込みください。<br>
                            （メッセージ欄に紹介者様のお名前をご記入ください。）<br>
                            <br>
                            下記のメールアドレスにご紹介いただく方のご連絡先(お電話番号)をお知らせいた <br>
                            だければ、こちらからご案内させていただきます。<br>
                            <br>
                            <a href="mailto:kanri@best-semi.com">kanri@best-semi.com</a>
                            </p>
                        </div>
                        <div class="apply-btn">
                            <a href="<?php echo esc_html( home_url('/') ) ?>simulation/#wpcf7-f212-o1"">お申し込み</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();
