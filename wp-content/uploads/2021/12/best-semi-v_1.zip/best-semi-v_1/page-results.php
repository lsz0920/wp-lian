<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>r</span>esults</h2>
                <h3 class="jp-ttl">帰国生入試合格実績</h3>
            </div>
            <div class="sl-subpage-list">
                <ul>
                    <li><a href="#">模擬試験</a></li>
                    <li><a href="#">教育セミナートップ</a></li>
                    <li><a href="#">入試実績</a></li>
                    <li><a href="#">子供新聞</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </div>
        </div>
        <div class="sl-subpage-results-inn">
            <div class="breadcrumbs inner" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-results-inn-content">
                <div class="sl-subpage-results-inn-content-ttl">
                    <div class="content-ttl">
                        <h2><span>今までにたくさんの生徒が合格しています！</span></h2>
                    </div>
                </div>
                <div class="sl-subpage-results-inn-content-box pd-box">
                    <div class="box-mv">
                        <figure>
                            <img src="<?php echo get_template_directory_uri(); ?>/img/results/results-mv.jpg" alt="img">
                        </figure>
                        <h2>
                            合格 <br>
                            おめでとう
                        </h2>
                    </div>
                    <div class="box-data">
                        <div class="box-data-list d-fl">
                            <div class="list-info">
                                <div class="list-info-inn">
                                    <div class="list-info-inn-ttl">
                                        <h2><span>中学校</span></h2>
                                    </div>
                                    <div class="list-info-inn-data">
                                        <ul>
                                            <li>学芸大附属国際教育中等教育学校</li>
                                            <li>東京都市大学付属中学校</li>
                                            <li>横浜国立大学横浜中学校</li>
                                            <li>関西学院千里国際中等部</li>
                                            <li>渋谷教育学園幕張</li>
                                            <li>広尾学園</li>
                                            <li>白百合学園</li>
                                            <li>茗渓学園</li>
                                            <li>昌平中学校</li>
                                            <li>宝仙学園</li>
                                            <li>山脇学園</li>
                                            <li>成蹊中学・高等学校</li>
                                            <li>都立立川国際中等教育学校</li>
                                            <li>玉川学園</li>
                                            <li>同志社国際中学校</li>
                                            <li>神戸国際中学校</li>
                                            <li>学習院女子中等部</li>
                                            <li>多摩大付属聖ヶ丘中学校</li>
                                            <li>南山国際中学高等学校</li>
                                            <li>御茶ノ水女子大付属中学校</li>
                                            <li>海陽学園</li>
                                            <li>桐光学園中学校</li>
                                            <li>頌栄女子学院中学校</li>
                                            <li>立命館宇治中学校</li>
                                            <li>文化学園大学杉並中学高等学校</li>
                                            <li>都立白鷗高校附属中学校</li>
                                            <li>聖光学院</li>
                                            <li>洗足学園</li>
                                            <li>立教女学院中学高等学校</li>
                                            <li>芦屋国際中学高等学校</li>
                                            <li>大妻中野中学高等学校</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="list-info">
                               <div class="list-info-inn">
                                    <div class="list-info-inn-ttl">
                                        <h2><span>高等学校</span></h2>
                                    </div>
                                    <div class="list-info-inn-data">
                                        <ul>
                                            <li>国際基督教大学高等学校</li>
                                            <li>頌栄女子中学高等学校</li>
                                            <li>立命館宇治高等学校</li>
                                            <li>神奈川総合高等学校</li>
                                            <li>神戸市立葺合高等学校</li>
                                            <li>横浜国際高等学校</li>
                                            <li>愛知淑徳高等学校</li>
                                            <li>目白研心高等学校</li>
                                            <li>かえつ有明中高等学校</li>
                                            <li>桐朋女子高等学校</li>
                                            <li>神戸国際高等学校</li>
                                            <li>東京都立国際高等学校</li>
                                            <li>玉川学園</li>
                                            <li>岡山県立総社高校</li>
                                            <li>土浦日本大学高等学校</li>
                                            <li>法政大学第2高校</li>
                                            <li>日本大学三島高等学校</li>
                                        </ul>
                                    </div>
                               </div>
                            </div>
                            <div class="list-info">
                                <div class="list-info-inn">
                                    <div class="list-info-inn-ttl">
                                        <h2><span>小学校</span></h2>
                                    </div>
                                    <div class="list-info-inn-data">
                                        <ul>
                                            <li>桐蔭学園小学校</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="list-info-inn">
                                    <div class="list-info-inn-ttl">
                                        <h2><span>大学</span></h2>
                                    </div>
                                    <div class="list-info-inn-data">
                                        <ul>
                                            <li>日大芸術学部</li>
                                            <li>秋田国際教養大学</li>
                                            <li>上智大学</li>
                                            <li>早稲田大学</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="list-info-inn">
                                    <div class="list-info-inn-data">
                                        <ul>
                                            <li><span>AP Japanese Language</span></li>
                                            <li><span>and Culture</span></li>
                                            <li>00名</li>
                                            <li></li>
                                            <li><span>JLPT（日本語能力検定試験）</span></li>
                                            <li>N1 　00名</li>
                                            <li>N2 　00名</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-results-inn-content-box">
                    <div class="box-ttl">
                        <h2>帰国生入試は「英・国・算」をおさえろ！</h2>
                    </div>
                    <div class="box-data">
                        <div class="box-data-content d-fl">
                            <div class="box-data-content-box">
                                <div class="data-ttl">
                                    <h3>英語</h3>
                                </div>
                                <div class="data-info">
                                <p>
                                    なるべく英検はとっておく。一般的に評価されるのは、英検2級から準1級です。<br>
                                    英作文は、必ず専門の先生に見てもらってください。しっかりEssay方式の書き方のマスターしておきましょう。<br>
                                    （学校によっては、題材、形式は、それぞれです。志望校の形式になれておいてください。）
                                </p>
                                </div>
                            </div>
                            <div class="box-data-content-box">
                                <div class="data-ttl">
                                    <h3>国語</h3>
                                </div>
                                <div class="data-info">
                                    <p>
                                        日本の国語の問題形式になれておいてください。<br>
                                        「何字以内で本文から抜き出しなさい」などの問題は、慣れていないと、なかなか正解をだせません。<br>
                                        そして、読書習慣は、なるべくつけておいてください。日本の国語の問題を解く上でも大切です。
                                    </p>
                                </div>
                            </div>
                            <div class="box-data-content-box">
                                <div class="data-ttl">
                                    <h3>算数</h3>
                                </div>
                                <div class="data-info">
                                    <p>
                                        応用問題は、必ず出題されます。<br>
                                        慣れないと、どう解いていいのか分からないので、応用問題に慣れ、志望校の問題パターンを飲み込むことが大切です。<br>
                                        時間配分になれること。そして、わからない問題は、とばすことも必要です。100満点をを目指す必要はありません。
                                    </p>
                                </div>
                            </div>
                            <div class="box-data-content-box">
                                <div class="data-ttl">
                                    <h3>面接</h3>
                                </div>
                                <div class="data-info">
                                    <p>
                                    必ず専門家と模擬面接をしておいてください。<br>
                                        提出した調査書や自己アピール書から質問されることが多いので、提出した書類に書いたことは必ず確認しておきましょう。<br>
                                        渋谷教育学園渋谷のように、グループ面接もあれば、学芸大付属のようにグループ面接でかつ、コミュニケーション能力を見るような、特殊な面接もあります。
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-results-inn-content-box">
                    <div class="box-ttl">
                        <h2>学校側が帰国生を取りたい理由</h2>
                    </div>
                    <div class="box-data-content">
                        <div class="box-data-content-info">
                            <p>
                                多くの学校が帰国生のポテンシャルに期待しています。<br>
                                幼い頃に海外の学校に通うことになって、最初は言葉も分からなかったのに、それを克服したという実績が高く評価されます。<br>
                                最初は、なかなか成績が伸びなくとも、その後の成績の伸びを評価するケースが大変多くあります。
                            </p>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-results-inn-content-thumbnail">
                    <div class="thumbnail-list d-fl">
                        <div class="thumbnail-box">
                            <figure>
                                <img src="<?php echo get_template_directory_uri(); ?>/img/results/thumbnail01.png" alt="img">
                            </figure>
                            <h2><a href="#">帰国生入試分析ブログ</a></h2>
                        </div>
                        <div class="thumbnail-box">
                            <figure>
                                <img src="<?php echo get_template_directory_uri(); ?>/img/results/thumbnail02.png" alt="img">
                            </figure>
                            <h2><a href="#">帰国生入試を徹底分析</a></h2>
                        </div>
                    </div>
                </div>
            </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();