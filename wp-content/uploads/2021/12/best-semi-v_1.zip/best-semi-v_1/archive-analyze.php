<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>a</span>nalyze</h2>
                <h3 class="jp-ttl">帰国生受入校</h3>
            </div>
            <div class="sl-subpage-list">
                <ul>
                    <li><a href="#">模擬試験</a></li>
                    <li><a href="#">教育セミナートップ</a></li>
                    <li><a href="#">入試実績</a></li>
                    <li><a href="#">子供新聞</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </div>
        </div>
        <div class="sl-subpage-analyze-inn">
            <div class="breadcrumbs inner" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-analyze-inn-content">
                <div class="sl-subpage-analyze-inn-content-list">
                    <div class="list-ttl">
                        <h2><span>帰国生受入校一覧</span></h2>
                    </div>
                    <div class="list-item">
                        <?php
                            $args = array(
                            'post_type'         => 'analyze',
                            'posts_per_page'    => -1,
                            'exclude'           => ''
                            );
                            $loop = new WP_Query($args); 
                        ?>
                        <ul class="d-fl">
                        <?php while($loop->have_posts()): $loop->the_post(); ?>
                            <li><a href="#<?php echo get_the_title(); ?>"><?php echo get_the_title(); ?></a></li>
                            <?php endwhile; wp_reset_query(); ?>
                        </ul>
                    </div>
                </div>
                <div class="sl-subpage-analyze-inn-content-box box-shadow">
                    <div class="box-data">
                    <?php while($loop->have_posts()): $loop->the_post(); ?>
                        <div class="box-data-wrap" id="<?php echo get_the_title(); ?>">
                            <div class="box-data-ttl">
                                <h2><span><?php echo get_the_title(); ?>地方</span></h2>
                            </div>
                            <div class="box-data-content">
                                <table>
                                    <thead>
                                        <th>都道府県</th>
                                        <th>市区町村</th>
                                        <th>国公立</th>
                                        <th>共学別学</th>
                                        <th colspan="2">学校名</th>
                                    </thead>
                                    <tbody>
                                    <?php $fields = CFS()->get('analyze_loop');?>
                                    <?php if ($fields):?>
                                    <?php foreach ( $fields as $field ):?>
                                        <tr>
                                        <?php if($field['township_name'] != ''): ?>
                                            <td><?php echo $field['township_name'];?></td>
                                        <?php endif; ?>
                                        <?php if($field['city_name'] != ''): ?>
                                            <td><?php echo $field['city_name'];?></td>
                                        <?php endif; ?>
                                        <?php if($field['national_public'] != ''): ?>
                                            <td><?php echo $field['national_public'];?></td>
                                        <?php endif; ?>
                                        <?php if($field['co_deucation'] != ''): ?>
                                            <td><?php echo $field['co_deucation'];?></td>
                                        <?php endif; ?>
                                        <?php if($field['school_name'] != ''): ?>
                                            <td><?php echo $field['school_name'];?></td>
                                        <?php endif; ?>
                                        </tr>
                                    <?php endforeach; endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endwhile; ?>
                    </div>
                </div>
                <div class="sl-subpage-analyze-inn-content-thumbnail">
                    <div class="thumbnail-list d-fl">
                        <a href="<?php echo esc_html( home_url('/') ) ?>thorough-analysis/entry-exams/" class="thumbnail-box">
                            <article>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/analyze/img01.png" alt="" class="">
                                </figure>
                                <h3>入試について</h3>
                            </article>
                        </a>
                        <a href="<?php echo esc_html( home_url('/') ) ?>" class="thumbnail-box">
                            <article>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/analyze/img02.png" alt="" class="">
                                </figure>
                                <h3>市立中って</h3>
                            </article>
                        </a>
                        <a href="<?php echo esc_html( home_url('/') ) ?>" class="thumbnail-box">
                            <article>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/analyze/img03.png" alt="" class="">
                                </figure>
                                <h3>帰国性受入校</h3>
                            </article>
                        </a>
                        <a href="<?php echo esc_html( home_url('/') ) ?>" class="thumbnail-box">
                            <article>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/analyze/img04.png" alt="" class="">
                                </figure>
                                <h3>オンライン学校説明会</h3>
                            </article>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();
