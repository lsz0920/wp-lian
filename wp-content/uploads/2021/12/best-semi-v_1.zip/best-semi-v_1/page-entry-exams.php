<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>a</span>nalyze</h2>
                <h3 class="jp-ttl">入試について</h3>
            </div>
            <div class="sl-subpage-list">
                <ul>
                    <li><a href="#">模擬試験</a></li>
                    <li><a href="#">教育セミナートップ</a></li>
                    <li><a href="#">入試実績</a></li>
                    <li><a href="#">子供新聞</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </div>
        </div>
        <div class="sl-subpage-entry-exam-inn">
            <div class="breadcrumbs inner" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-entry-exam-inn-content">
                <div class="sl-subpage-entry-exam-inn-content-ttl">
                    <div class="content-ttl">
                        <h2><span>入試について</span></h2>
                    </div>
                </div>
                <div class="sl-subpage-entry-exam-inn-content-box">
                    <div class="box-ttl">
                        <h2>一口に帰国生入試といっても、学校によって千差万別です。<br>
                        まずは、帰国生入試とはどういうものか見ていきましょう。</h2>
                    </div>
                    <div class="box-data">
                        <div class="box-data-ttl">
                            <h2><span>帰国生受験の最大のメリットは？</span></h2>
                        </div>
                        <div class="box-data-content">
                            <div class="data-info">
                                <p>帰国生受験の最大のメリットは、科目数が少ない事です。帰国生を多く受け入れているほとんどの学校は、入試科目を国語、算数、英語の3教科にしています。<br>
                                一般入試でも4科又は2科の選択にしている学校もありますが、一般入試の場合、国算2科受験の方が合格率が低く、よりハードルが高くなっています。　帰国生の場合一般受験と違って不利にならずに国語、算数の2科に絞り込めるので、受験対策をしていく際に断然有利になります。<br>
                                そして英語は自分の武器にしましょう。
                                </p>
                            </div>
                        </div>
                        <div class="box-data-content">
                            <div class="data-info info-border">
                                <h4>英語が得意な場合</h4>
                                <p>英語が得意なお子さまには英語を重視している学校が有利といえます。攻玉社、渋谷教育学園幕張、頌栄女子学院、洗足学園等、英語のみで受験できる学校もあります。<br>
                                    ※在留期間等によって受験資格が異なる場合がありますので、各学校にご確認下さい
                                </p>
                            </div>
                        </div>
                        <div class="box-data-ttl">
                            <h2><span>競争率：帰国生は2.1倍。一般生は2.5倍</span></h2>
                        </div>
                        <div class="box-data-content">
                            <div class="data-info">
                                <p>これは帰国生と一般生の中学受験の競争率を比較したものです。（一般生は1回目入試のみを対象）<br>
                                (人気校25校の平均競争率)</p>
                            </div>
                            <table>
                                <thead>
                                    <th>学校名</th>
                                    <th>帰国生</th>
                                    <th>一般生</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>攻玉社中学校</td>
                                        <td>1.6</td>
                                        <td>2.3</td>
                                    </tr>
                                    <tr>
                                        <td>渋谷教育学園渋谷中学校</td>
                                        <td>3.7</td>
                                        <td>2.3</td>
                                    </tr>
                                    <tr>
                                        <td>東京女学館中学校</td>
                                        <td>1.5</td>
                                        <td>2.3</td>
                                    </tr>
                                    <tr>
                                        <td>頌栄女子中学校</td>
                                        <td>約1.2（公表されていません）</td>
                                        <td>2.3</td>
                                    </tr>
                                    <tr>
                                        <td>慶應義塾湘南藤沢中等部</td>
                                        <td>3.7</td>
                                        <td>2.3</td>
                                    </tr>
                                    <tr>
                                        <td>学習院女子中等科</td>
                                        <td>1.8</td>
                                        <td>2.3</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-entry-exam-inn-content-box">
                    <div class="box-ttl">
                        <h2>
                            おおざっぱに帰国生入試がどのようなものかつかめたでしょうか? <br>
                            それでは、帰国生受験について分析していきましょう。<br>
                            帰国生入試の場合、自分の行きたい学校を早く決めて、<br>
                            絞り込んだ対策を取るのが一番の近道になります。<br>
                        </h2>
                    </div>
                    <div class="box-data">
                        <div class="box-data-ttl">
                            <h2><span>帰国生受験徹底分析：自分にとっての難関校は？</span></h2>
                        </div>
                        <div class="box-data-content">
                            <div class="data-info">
                                <p>
                                    現地校に通学している人にとっては、4科入試を要求している学校は、対策の取りにくい学校と言えるでしょう。競争率以上に受験の準備に時間がかかります。 <br><br>

                                    ほとんどの学校で、国算は必須ですが入試問題が一般生と同じか、帰国生用になっているかで、対策が大きく変わります。特に算数については。一般生と同じ入試問題であれば、特殊算等、特別な受験対策をする必要があります。<br><br>

                                    国、算が帰国生用の問題であれば、学校の考え方としては、英語の能力、勉強の意欲を優先にして、最低限国語、算数が入学後、授業に付いて行ける学力があるかを確認する為のものです。教科書主体で勉強し、最後3ヶ月間はなるべく多くの問題をこなし、問題慣れする事が大事です。<br><br>

                                    英語主体の入試の場合、「読む」「書く」「聞く」「話す」が試されるケースが多いです。特に一番英語の実力がわかると言われるのが英作文です。日常会話や友達同士の会話ができるというだけではなく、文法、単語量もつけておくことが必要です。又、渋谷教育学園や桐朋女子中学校のように論旨を明確にした、Paragraph式のEaasyを要求される場合もあります。
                                </p>
                            </div>
                            <div class="data-img">
                                <img src="<?php echo get_template_directory_uri(); ?>/img/analyze/graph.jpg" alt="img">
                                <span class="note">*在留期間等によっても、入試の内容が変る場合がありますので、必ず各学校に確認してください。</span>
                            </div>
                            <div class="sub-tb-ttl">
                                <h3>5年生から効果のある勉強法</h3>
                            </div>
                            <div class="box-data-content">
                                <table class="sub-tb">
                                    <tr>
                                        <th>国　語</th>
                                        <td>
                                            本を読む。<br>
                                            読んだ後に、家族で本について話してみる。
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>算　数</th>
                                        <td>
                                            ドリル等の計算を毎日やってください。<br>
                                            そして、一度始めた問題集は最初から最後まで必ずやる。
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>英　語</th>
                                        <td>
                                            英語で日記を書く。<br>
                                            添削はしなくてよいので、誰かに読んでもらう交換日記が効果的です。
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-entry-exam-inn-content-thumbnail">
                    <div class="thumbnail-list d-fl">
                        <a href="<?php echo esc_html( home_url('/') ) ?>thorough-analysis/entry-exams/" class="thumbnail-box">
                            <article>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/analyze/img01.png" alt="" class="">
                                </figure>
                                <h3>入試について</h3>
                            </article>
                        </a>
                        <a href="<?php echo esc_html( home_url('/') ) ?>thorough-analysis/private-school/" class="thumbnail-box">
                            <article>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/analyze/img02.png" alt="" class="">
                                </figure>
                                <h3>市立中って</h3>
                            </article>
                        </a>
                        <a href="<?php echo esc_html( home_url('/') ) ?>" class="thumbnail-box">
                            <article>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/analyze/img03.png" alt="" class="">
                                </figure>
                                <h3>帰国性受入校</h3>
                            </article>
                        </a>
                        <a href="<?php echo esc_html( home_url('/') ) ?>" class="thumbnail-box">
                            <article>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/analyze/img04.png" alt="" class="">
                                </figure>
                                <h3>オンライン学校説明会</h3>
                            </article>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();