$(window).on("load", function() {
    $(".main-ttl").each(function(i, el) {
        ScrollTrigger.create({
            trigger: el,
            start: "top 100%",
            end: "bottom 100px",
            onEnter: () => scrollFadeUpAni($(this)),
        });
    });

    function scrollFadeUpAni(el) {
        $(el).addClass('fade-in');
    }

    $(".l-contactbnr-inn h2 span").each(function(el) {
        ScrollTrigger.create({
            trigger: $(this),
            start: "top 60%",
            end: "60% top",
            onEnter: () => scrollLineAni($(this)),
        });
    });

    function scrollLineAni(el) {
        $(el).addClass('line-animate');
    }
});

$(document).ready(function($) {

    $('.faq-inn-content .faq-list .faq-list-wrap h2').on('click', function() {
        $(this).next().toggleClass('open');
    });
    $('.faq-list-inner dl,.faq-list-detail dl').on('click', function() {
        $(this).children('dt').toggleClass('active');
    });
    $('.l-hd-inn-R-01 .language').on('click', function() {
        $(this).children('li:last-child').slideToggle();
    });
    // menu trigger js
    $('.menu-bar,.close-menu').on('click', function() {
        $('body').toggleClass('noscroll');
        $('.l-hd-inn').toggleClass('show-menu');
    });

    // show for header menu
    if ($(window).width() < 1100) {
        $('.l-hd-inn-nav>li.show-more>a').on('click', function() {
            $(this).toggleClass('active');
            $(this).next('.dropdown').toggleClass('show-dropdown');
        });
    }

    // show for hader sub list
    if ($(window).width() < 768) {
        $('.ft-inn-nav nav h2').on('click', function() {
            $(this).toggleClass('active');
            $(this).next('ul').slideToggle();
        });
    }

    //header menu hover function
    $('.l-hd-inn-nav li').hover(function() {
        $(this).children('.dropdown').toggleClass('show');
        if ($(window).width() < 1100) {
            $(this).children('.dropdown').removeClass('show');
        }
    });

});

//add class related link
$(function () {
    var cUrl = window.location.href;
    $(".sl-course-inn .course-list li a,.list-item ul li a").each(function () {
        if ($(this).attr("href") == cUrl) {
            $(this).addClass("active");
        }
    });
});

//go to top js
jQuery(function($) {
    $(".top-btn").hide();
    $(window).on("scroll", function() {
        if ($(this).scrollTop() > 200) {
            $(".top-btn").fadeIn("fast");
        } else {
            $(".top-btn").fadeOut("fast");
        }
        scrollHeight = $(document).height();
        scrollPosition = $(window).height() + $(window).scrollTop();
        footHeight = $(".ft-copy").innerHeight();

        if (scrollHeight - scrollPosition <= footHeight) {
            $(".top-btn").css({
                "position": "absolute",
                "bottom": "90px"
            });
        } else {
            $(".top-btn").css({
                "position": "fixed",
                "bottom": "30px"
            });
        }
    });
    $('.top-btn').click(function() {
        $('body,html').animate({
            scrollTop: 0
        }, 400);
        return false;
    });
});