$('.l-mv-inn-slider').slick({
    autoplay: true,
    arrows: false,
    slidesToShow: 4,
    slidesToScroll: 1,
    speed: 300,
    dots: true,
    responsive: [
        {
          breakpoint: 1100,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
          }
        },
        {
            breakpoint: 768,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1
            }
          }
    ]
});

$('.review-list').slick({
    // autoplay: true,
    arrows: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    speed: 300,
    dots: true,
    centerMode: true,
    adaptiveHeight: true,
    centerPadding: '0',
});

// add years in free-trial page
var year_select = $('#bd-year');
if (year_select.length > 0) {

    var now_year = Number(new Date().getFullYear());
    var format = '';
    for (var start_year = 1970; start_year <= now_year; start_year++) {
        format += '<option value="' + start_year + '">' + start_year + '</option>';
    }

    year_select.html(format);

}
