<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>s</span>tyle</h2>
                <h3 class="jp-ttl">受講スタイル</h3>
            </div>
            <div class="sl-subpage-list">
                    <ul>
                        <li><a href="#">模擬試験</a></li>
                        <li><a href="#">教育セミナートップ</a></li>
                        <li><a href="#">入試実績</a></li>
                        <li><a href="#">子供新聞</a></li>
                        <li><a href="#">Facebook</a></li>
                        <li><a href="#">Blog</a></li>
                    </ul>
            </div>
        </div>
        <div class="sl-subpage-style-inn">
            <div class="breadcrumbs inner" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="style-wrap">
                <div class="style-content">
                    <div class="content-list01">
                        <div class="content-list01-ttl">
                            <h2>お申し込みから入会・無料体験レッスンまで</h2>
                        </div>
                        <div class="content-list01-inn">
                            <div class="step">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/step/img01.png" alt="" class="">
                                </figure>
                            </div>
                            <article class="d-fl">
                                <h2><span>お申し込み</span></h2>
                                <p>お申込み専用フォームに必要事項を記入してお気軽にお申込みください。ご質問などございましたら、メッセージ欄にご記入ください。
                                    無料体験お申込み</p>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/img01.png" alt="" class="">
                                </figure>
                            </article>
                        </div>
                        <div class="content-list01-inn">
                            <div class="step">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/step/img02.png" alt="" class="">
                                </figure>
                            </div>
                            <article class="d-fl">
                                <h2><span>ご連絡</span></h2>
                                <p>お申し込みをいただいてから1営業日以内に当社の担当者からお電話orメールにてご連絡を差し上げます。</p>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/img02.png" alt="" class="">
                                </figure>
                            </article>
                        </div>
                        <div class="content-list01-inn">
                            <div class="step">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/step/img03.png" alt="" class="">
                                </figure>
                            </div>
                            <article class="d-fl">
                                <h2><span>学力チェック</span></h2>
                                <p>お申し込みをいただいてから1営業日以内に当社の担当者からご連絡を差し上げます。</p>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/img03.png" alt="" class="">
                                </figure>
                            </article>
                        </div>
                        <div class="content-list01-inn">
                            <div class="step">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/step/img04.png" alt="" class="">
                                </figure>
                            </div>
                            <article class="d-fl">
                                <h2><span>教材送付</span></h2>
                                <p>ヒアリング結果やご要望に応じた教材をお送りします。機材が必要であれば一緒にお送りします。教材・機材はお試し期間中は無料でご利用いただけるので費用は一切かかりません。</p>
                                <figure class="style-img">
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/img04.png" alt="" class="">
                                </figure>
                            </article>
                        </div>
                        <div class="content-list01-inn">
                            <div class="step">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/step/img05.png" alt="" class="">
                                </figure>
                            </div>
                            <article class="d-fl">
                                <h2><span>無料体験開始</span></h2>
                                <p>教材が届いたら、いよいよ授業のスタートです！最初の1ヵ月は無料で体験していただけます。無料体験レッスン終了後、正式入会となります。継続されない場合は、教材・機材を無料で回収いたします。</p>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/img05.png" alt="" class="">
                                </figure>
                            </article>
                        </div>
                    </div>
                </div>
                <div class="style-content">
                    <div class="content-list02">
                        <div class="content-list02-ttl">
                            <h2>授業を受けてみよう！</h2>
                        </div>
                        <div class="content-list02-inn">
                            <div class="point">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/point/img01.png" alt="" class="">
                                </figure>
                            </div>
                            <article class="d-fl">
                                <div class="info">
                                    <h2><span>オンライン授業</span></h2>
                                    <p>授業は、skype(スカイプ)を使ったオンライン授業です。
                                    自宅に居ながら、授業を受けることができます。
                                    ベストゼミナールは、マンツーマン授業・完全担任制を取っているので、お子様の学力や性格に合わせた最適な授業を提供します。
                                    グループレッスンとは違い、先生と生徒のマンツーマン授業なので、自分で話す機会が格段に多く、より集中した授業が行えます。</p>
                                </div>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/img06.png" alt="" class="">
                                </figure>
                            </article>
                        </div>
                        <div class="content-list02-inn">
                            <div class="point">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/point/img02.png" alt="" class="">
                                </figure>
                            </div>
                            <article class="d-fl">
                                <div class="info">
                                    <h2><span>わかりやすい授業</span></h2>
                                    <p>むずかしいキーボード操作は不要です。
                                    パソコンは、テレビ電話を受信するために使用します。
                                    画面を通してホワイトボードや図表を使ってわかりやすい授業を行います。</p>
                                </div>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/img07.png" alt="" class="">
                                </figure>
                            </article>
                        </div>
                        <div class="content-list02-inn">
                            <div class="point">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/point/img03.png" alt="" class="">
                                </figure>
                            </div>
                            <article class="d-fl">
                                <div class="info">
                                    <h2><span>同じテキスト見ながら</span></h2>
                                    <p>先生と生徒は同じテキストを見ながら授業を進めます。同じものを見ているので、授業もスムーズ。
                                    テキストは日本の教科書準拠のものを使います。
                                    後で復習できるように、テキストやノートに教わったことを書いておきましょう。</p>
                                </div>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/img08.png" alt="" class="">
                                </figure>
                            </article>
                        </div>
                        <div class="content-list02-inn">
                            <div class="point">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/point/img04.png" alt="" class="">
                                </figure>
                            </div>
                            <article class="d-fl">
                                <div class="info">
                                    <h2><span>保護者の方へメールで授業の報告</span></h2>
                                    <p>毎授業後、講師から保護者の方へメールで授業報告をお送りします。<br>
                                    授業中の様子や進み具合などを把握できるので安心です。</p>
                                </div>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/img09.png" alt="" class="">
                                </figure>
                            </article>
                        </div>
                        <div class="content-list02-inn">
                            <div class="point">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/point/img05.png" alt="" class="">
                                </figure>
                            </div>
                            <article class="d-fl">
                                <div class="info">
                                    <h2><span>定期面談</span></h2>
                                    <p>入会後、1ヵ月目・3ヵ月目・6ヶ月目に教室長が保護者と生徒との三者面談をさせていただきます。
                                    家庭学習のやり方、受験対策、そのほか勉強で困っていることなどをご相談ください。</p>
                                </div>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/style/img10.png" alt="" class="">
                                </figure>
                            </article>
                        </div>
                    </div>
                </div>
                <div class="style-content">
                    <div class="content-list03">
                        <div class="content-list03-ttl">
                            <h2>授業開始時間</h2>
                        </div>
                        <div class="content-list03-info">
                            <div class="content-hd">
                                <p>北米の方：日曜日～金曜日</p>
                            </div>
                            <table>
                                <thead>
                                    <th>ハワイ</th>
                                    <th>西海岸</th>
                                    <th>Mountain Time</th>
                                    <th>Central Time</th>
                                    <th>東海岸</th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>午後2:30</td>
                                        <td>午後4:30</td>
                                        <td>午後5:30</td>
                                        <td>午後6:30</td>
                                        <td>午後7:30</td>
                                    </tr>
                                    <tr>
                                        <td>午後3:30</td>
                                        <td>午後5:30</td>
                                        <td>午後6:30</td>
                                        <td>午後7:30</td>
                                        <td>午後8:30</td>
                                    </tr>
                                    <tr>
                                        <td>午後4:30</td>
                                        <td>午後6:30</td>
                                        <td>午後7:30</td>
                                        <td>午後8:30</td>
                                        <td>午後9:30</td>
                                    </tr>
                                    <tr>
                                        <td>午後5:30</td>
                                        <td>午後7:30</td>
                                        <td>午後8:30</td>
                                        <td>午後9:30</td>
                                        <td>午後10:30</td>
                                    </tr>
                                    <tr>
                                        <td>午後6:30</td>
                                        <td>午後8:30</td>
                                        <td>午後9:30</td>
                                        <td>午後10:30</td>
                                        <td>午後11:30</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-hd">
                                <p>アジア・太平洋の方：月曜日～金曜日</p>
                            </div>
                            <table>
                                <tbody>
                                    <tr>
                                        <td>日本時間</td>
                                        <td>午前9:30～午後9:00（土曜日は、午後6:00まで）</td>
                                    </tr>
                                    <tr>
                                        <td>オーストラリア</td>
                                        <td>午前10:30～午後8:00（土曜日は、午後5:00まで）</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-ft d-fl">
                                <p>それ以外の時間帯をご希望の方はスタッフにご相談ください。</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();
