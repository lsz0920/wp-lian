<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>f</span>aq</h2>
                <h3 class="jp-ttl">よくある質問</h3>
            </div>
            <div class="sl-subpage-list">
                <ul>
                    <li><a href="#">模擬試験</a></li>
                    <li><a href="#">教育セミナートップ</a></li>
                    <li><a href="#">入試実績</a></li>
                    <li><a href="#">子供新聞</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </div>
        </div>
        <div class="sl-subpage-faq-inn">
            <div class="breadcrumbs inner" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-faq-inn-content">
                <?php
                    $args = array(
                    'post_type'         => 'faq',
                    'posts_per_page'    => -1,
                    'exclude'           => ''
                    );
                    $loop = new WP_Query($args); 
                ?>
                    <div class="faq-category">
                        <ul class="d-fl">
                            <li><h3>カテゴリー</h3></li>
                            <?php while($loop->have_posts()): $loop->the_post(); ?>
                            <li><a href="#<?php echo get_the_title(); ?>"><?php echo get_the_title(); ?></a></li>
                            <?php endwhile; wp_reset_query(); ?>
                        </ul>
                    </div>
                <div class="faq-inn-content">
                    <div class="faq-list">
                        <?php while($loop->have_posts()): $loop->the_post(); ?>
                        <section class="faq-list-wrap faq-list-01" id="<?php echo get_the_title(); ?>">
                            <h3 class="faq-ttl"><span><?php echo get_the_title(); ?></span></h3>
                            <div class="faq-list-detail">
                                <?php $fields = CFS()->get('faq_loop');?>
                                <?php if ($fields):?>
                                <?php foreach ( $fields as $field ):?>
                                <dl>
                                    <?php if($field['question'] != ''): ?>
                                        <dd><?php echo $field['question'];?></dd>
                                    <?php endif; ?>
                                    <?php if($field['answer'] != ''): ?>
                                        <dt><?php echo $field['answer'];?></dt>
                                    <?php endif; ?>
                                </dl>
                                <?php endforeach; endif; ?>
                            </div>
                        </section>
                        <?php endwhile;?>
                    </div>
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();
