<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>e</span>ducation material</h2>
                <h3 class="jp-ttl">教材について</h3>
            </div>
            <div class="sl-subpage-list">
                <ul>
                    <li><a href="#">模擬試験</a></li>
                    <li><a href="#">教育セミナートップ</a></li>
                    <li><a href="#">入試実績</a></li>
                    <li><a href="#">子供新聞</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </div>
        </div>
        <div class="sl-subpage-material-inn">
            <div class="breadcrumbs inner" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-material-inn-content">
                <div class="sl-subpage-material-inn-content-box">
                    <div class="box-ttl">
                        <h2>教材の販売</h2>
                    </div>
                    <div class="box-data">
                        <div class="box-data-ttl">
                            <h2><span>小学生レベルの教材</span></h2>
                        </div>
                        <div class="box-data-content">
                            <div class="box-data-content-info">
                                <p>お子様のレベルに合わせて、教材を選択します。（漢字ドリル、計算ドリルは、自宅学習用です）</p>
                            </div>
                            <div class="box-data-content-list d-fl">
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img01.png" alt="">
                                    </figure>
                                    <p>
                                        教科書準拠教材 <br>
                                        小1～小3 ／$20 <br>
                                        小4～小6 ／$21
                                    </p>
                                </article>
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img02.png" alt="">
                                    </figure>
                                    <p>
                                        発展教材 <br>
                                        <span>(教科書には準拠していません）</span><br>
                                        小学3年生以上／$21
                                    </p>
                                </article>
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img03.png" alt="">
                                    </figure>
                                    <p>
                                        無学年式教材 <br>
                                        <span>(学年は表示されていません）</span><br>
                                        ／$8(各学年4冊～6冊)
                                    </p>
                                </article>
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img04.png" alt="">
                                    </figure>
                                    <p>
                                        漢字ドリル <br>
                                        ／$8.5
                                    </p>
                                </article>
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img05.png" alt="">
                                    </figure>
                                    <p>
                                        計算ドリル <br>
                                        $8.5
                                    </p>
                                </article>
                            </div>
                            <div class="box-data-ttl">
                                <h2><span>中学受験対策</span></h2>
                            </div>
                            <div class="box-data-content-list d-fl">
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img06.png" alt="">
                                    </figure>
                                    <p>
                                        $22
                                    </p>
                                </article>
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img07.png" alt="">
                                    </figure>
                                    <p>
                                        $22
                                    </p>
                                </article>
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img08.png" alt="">
                                    </figure>
                                    <p>
                                        $25
                                    </p>
                                </article>
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img09.png" alt="">
                                    </figure>
                                    <p>
                                        $33
                                    </p>
                                </article>
                            </div>
                            <div class="box-data-ttl">
                                <h2><span>中学生の教材</span></h2>
                            </div>
                            <div class="box-data-content-list d-fl">
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img10.png" alt="">
                                    </figure>
                                    <p>
                                        教科書準拠教材（国語）<br>
                                        ／$22
                                    </p>
                                </article>
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img11.png" alt="">
                                    </figure>
                                    <p>
                                        教科書準拠教材（数学）<br>
                                        ／$22
                                    </p>
                                </article>
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img12.png" alt="">
                                    </figure>
                                    <p>
                                        英語教材 <br>
                                        本冊 ／$22 <br>
                                        演習編 ／$8
                                    </p>
                                </article>
                            </div>
                            <div class="box-data-ttl">
                                <h2><span>高校受験対策（難関校対応）</span></h2>
                            </div>
                            <div class="box-data-content-list d-fl">
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img13.png" alt="">
                                    </figure>
                                    <p>
                                        $24
                                    </p>
                                </article>
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img14.png" alt="">
                                    </figure>
                                    <p>
                                        $24
                                    </p>
                                </article>
                            </div>
                            <div class="box-data-ttl">
                                <h2><span>日本語教材</span></h2>
                            </div>
                            <div class="box-data-content-list d-fl">
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img15.png" alt="">
                                    </figure>
                                    <p>
                                        $19
                                    </p>
                                </article>
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img16.png" alt="">
                                    </figure>
                                    <p>
                                        $19
                                    </p>
                                </article>
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img17.png" alt="">
                                    </figure>
                                    <p>
                                        無料・ダウンロード
                                    </p>
                                </article>
                            </div>
                            <div class="box-data-ttl">
                                <h2><span>機材</span></h2>
                            </div>
                            <div class="box-data-content-list d-fl">
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img18.png" alt="">
                                    </figure>
                                    <p>
                                        教科書準拠教材（国語）<br>
                                        ／$22
                                    </p>
                                </article>
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/material/img19.png" alt="">
                                    </figure>
                                    <p>
                                        教科書準拠教材（数学）<br>
                                        ／$22
                                    </p>
                                </article>
                            </div>
                            <table>
                                <tr>
                                    <th><span>送　料</span></th>
                                    <td>掲載金額には送料は含まれておりません。1オーダーにつき16ドルの送料が別途必要です。<br>
                                        ただし、1冊のみのご注文の場合は、送料は10ドルになります。
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();
