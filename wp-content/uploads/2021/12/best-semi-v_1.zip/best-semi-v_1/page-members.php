<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>M</span>EMBERS</h2>
                <h3 class="jp-ttl">会員メニュー</h3>
            </div>
            <div class="sl-subpage-list">
                    <ul>
                        <li><a href="#">模擬試験</a></li>
                        <li><a href="#">教育セミナートップ</a></li>
                        <li><a href="#">入試実績</a></li>
                        <li><a href="#">子供新聞</a></li>
                        <li><a href="#">Facebook</a></li>
                        <li><a href="#">Blog</a></li>
                    </ul>
            </div>
        </div>
        <div class="sl-subpage-member">
            <div class="sl-subpage-member-inn inner">
                <div class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
                    <?php if (function_exists('bcn_display')) {
                        bcn_display();
                    }?>
                </div>
                <div class="sl-subpage-member-inn-content">
                    <h3>会員ページ</h3>
                    <div class="content-inner">
                        <h4>ベストゼミナールからのお知らせ</h4>
                        <div class="content-seminar">
                            <p>生徒および保護者の皆さまに向けて、お知らせを掲載いたします。</p>
                            <div class="seminar-list d-fl">
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/members/icon01.png" alt="icon">
                                    </figure>
                                    <h5 class="title">長期お休み<br>退会について</h5>
                                    <p class="member-text">9月のお休み・退会申請期限は、<br><span>8月25日</span>までとなります。</p>
                                </article>
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/members/icon02.png" alt="icon">
                                    </figure>
                                    <h5 class="title">欠席などの連絡</h5>
                                    <p class="member-text">お休み連絡等のご連絡は、下記のメールにご連絡ください。</p>
                                    <div class="link">
                                        <a href="mailto:anri@best-semi.com">anri@best-semi.com</a>
                                    </div>
                                </article>
                                <article>
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/members/icon03.png" alt="icon">
                                    </figure>
                                    <h5 class="title">Study Tool</h5>
                                    <p class="member-text">こどもたちの自主学習のための勉強ツール</p>
                                    <div class="link">
                                        <a href="<?php echo esc_html( home_url('/') ) ?>material">使ってみる</a>
                                    </div>
                                </article>
                            </div>
                            <div class="schedule">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/members/icon04.png" alt="icon">
                                </figure>
                                <h5>休校日カレンダー</h5>
                                <div class="schedule-calendar d-fl">
                                    <article>
                                        <?php echo do_shortcode( '[wp_school_calendar]' ); ?>
                                    </article>
                                </div>
                                <div class="link">
                                    <a href="<?php echo esc_html( home_url('/') ) ?>schedule">年間カレンダーを見る</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="content-inner">
                        <h4>学習・授業</h4>
                        <div class="content-article d-fl">
                            <article>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/members/icon05.png" alt="icon">
                                </figure>
                                <h5 class="title">各種教材について</h5>
                                <p class="member-text">授業で使う教材のご紹介です。料金も掲載しておりますので、こちらからご確認できます。</p>
                                <div class="link">
                                    <a href="<?php echo esc_html( home_url('/') ) ?>material">教材について</a>
                                </div>
                            </article>
                            <article>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/members/icon06.png" alt="icon">
                                </figure>
                                <h5 class="title">ステップアップシート景品</h5>
                                <p class="member-text">頑張ったごほうび！<br>シートをクリアするとステキな景品がもらえるよ！</p>
                                <div class="link">
                                    <a href="<?php echo esc_html( home_url('/') ) ?>present">景品を見る</a>
                                </div>
                            </article>
                        </div>
                    </div>
                    <div class="content-inner">
                        <h4>特集</h4>
                        <p class="text">ベストゼミナール独自のサービスのご案内。</p>
                        <div class="content-article d-fl">
                            <article>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/members/icon07.png" alt="icon">
                                </figure>
                                <h5 class="title">イベント授業</h5>
                                <p class="member-text">不定期開催されるイベント、特別教室のご案内です。</p>
                                <div class="link">
                                    <a href="<?php echo esc_html( home_url('/') ) ?>event">詳しく見る</a>
                                </div>
                            </article>
                            <article>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/members/icon08.png" alt="icon">
                                </figure>
                                <h5 class="title">友人紹介制度について</h5>
                                <p class="member-text">お友達のご紹介による授業料割引のご案内</p>
                                <div class="link">
                                    <a href="<?php echo esc_html( home_url('/') ) ?>friend">詳しく見る</a>
                                </div>
                            </article>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();
