<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>a</span>nalyze</h2>
                <h3 class="jp-ttl">入試について</h3>
            </div>
            <div class="sl-subpage-list">
                <ul>
                    <li><a href="#">模擬試験</a></li>
                    <li><a href="#">教育セミナートップ</a></li>
                    <li><a href="#">入試実績</a></li>
                    <li><a href="#">子供新聞</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </div>
        </div>
        <div class="sl-subpage-private-school-inn">
            <div class="breadcrumbs inner" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-private-school-inn-content">
                <div class="sl-subpage-private-school-inn-content-ttl">
                    <div class="content-ttl">
                        <h2><span>私立中学って？</span></h2>
                    </div>
                </div>
                <div class="sl-subpage-private-school-inn-content-box">
                    <div class="box-ttl">
                        <h2>さあ、帰国生にとって私立中学とはどんなところでしょうか？ <br>
                            私立中学の先生の話を聞きながら一緒に見ていきましょう。</h2>
                    </div>
                    <div class="box-data">
                        <div class="box-data-ttl">
                            <h2><span>なぜ私立？ 帰国生の3人に1人は私立か国立に行く！</span></h2>
                        </div>
                        <div class="box-data-content">
                            <div class="data-info">
                                <p>
                                    近年帰国生を受け入れる私立中学が増え、また帰国生も私立中学へ入学する人が増えています。
                                    <br><br>
                                    一般の小学生の受験率は<span>17%</span> <br>
                                    それに対し、<span>帰国生は31%の</span>人が私立中学に入学しています。（国立も含めると35%）
                                    <br><br>
                                    理由として挙げられるのは、
                                    <br><br>
                                </p>
                                <ul>
                                    <li>帰国枠受験を利用したい</li>
                                    <li>英語能力の保持、向上に力を入れている</li>
                                    <li>国数等の補習をしてくれる</li>
                                    <li>進学率が高い</li>
                                    <li>公立よりも風紀が守られている</li>
                                    <li>中高一貫校が多く、高校受験をしなくてよい</li>
                                    <li>大学の推薦枠がある</li>
                                </ul>
                                <p>
                                    反面「レベルの高い私立中学に入学して、授業についていけるか？」というのが多くの人が心配することです。
                                    <br><br>
                                    一口に私立中学と言っても、学校によって様々です。各校帰国生の受入れに対しては非常に考えられた体制を作っており、帰国生に対して期待もしています。
                                </p>
                            </div>
                        </div>
                        <div class="box-data-ttl">
                            <h2><span>学校は帰国生に期待している！</span></h2>
                        </div>
                        <div class="box-data-content">
                            <div class="data-info">
                                <p>
                                    現場の先生方は口をそろえて、「帰国生の方にぜひ入学してほしい」と言います。<br>
                                    いくつか現場の先生が帰国生に期待する事を紹介してみます。
                                </p>
                            </div>
                            <table>
                                <tr>
                                    <th>頌栄女子学院</th>
                                    <td>海外で培った独自の価値感</td>
                                </tr>
                                <tr>
                                    <th>大妻中野中学</th>
                                    <td>国際性</td>
                                </tr>
                                <tr>
                                    <th>学習院中等科</th>
                                    <td>独自の視野</td>
                                </tr>
                                <tr>
                                    <th>渋谷教育学園渋谷</th>
                                    <td>異なる視野、多様性は21世紀のキーワード</td>
                                </tr>
                                <tr>
                                    <th>桐朋女子中学校</th>
                                    <td>多様性（いろんな価値感を持った人がいる事）</td>
                                </tr>
                                <tr>
                                    <th>成蹊中学校</th>
                                    <td>素直さ</td>
                                </tr>
                            </table>
                            <div class="data-info">
                                <p>
                                    <span>そして多くの学校が帰国生に現地にいる間に一番やっておいてほしい事</span><br>
                                    「現地でしか体験できない事にどっぷり浸かって体験して下さい」<br>
                                    このように学校側も帰国生が海外で培った経験、価値感をかけがえのないものと認識した上で、帰国生の受入れをしています。それは、帰国生にとって、やはり「優しい環境」といえるでしょう。
                                </p>
                            </div>
                            <div class="box-data-ttl">
                                <h2><span>帰国生の実力は? 実際、授業について行けるのか。</span></h2>
                            </div>
                            <div class="data-info">
                                <p>
                                    帰国生の実力について私立中学の先生に聞くと、多くの場合意外な答えが返ってきます。<br>
                                    <span>「高校１年生位の段階では、帰国生の方が優秀な場合が多い。」</span><br>
                                    中学1、2年生では、国語、数学、社会等遅れを取り戻すのにある程度苦労します。もちろん、個人差はありますが、傾向として帰国生が中3から高1で一般生を追い抜く場合が多い。その理由として、現場の先生方は次のように分析しています。
                                    <br><br>
                                    <span>理由は</span><br>
                                <p>
                                <ul>
                                    <li>集中力がある：小学校から現地校の授業について行く為、集中力が高い。</li>
                                    <li>素直さ：先生のいう事を素直にやる事が学力を伸ばす。</li>
                                    <li>英語ができる子は、国語もできる。</li>
                                    <li>現地校の授業について行く為、学習習慣がついている。</li>
                                    <li>意欲がある。（現地校でどっぷり浸かって、活動的な子は意欲がある）</li>
                                    <li>英語力が他の教科分も引き上げる。</li>
                                </ul>
                                <p><span>反対についていけなくなる生徒の傾向は</span></p>
                                <ul>
                                    <li>意欲がない。</li>
                                    <li>現地での経験が乏しく、帰国後の事を考えすぎて中途半端な場合。</li>
                                    <li>国語力、日本語の語彙が少ないと社会科でついて行けない。</li>
                                </ul>
                                <p>
                                    帰国生の入試の時に「意欲」「現地校での活動」等、どれだけ帰国生が現地で活動的にやってきたかを、重要視するケースが多くあります。その理由として、帰国生の潜在的な実力に期待しています。<br>
                                    現地校の活動　=　英語力 <br>
                                    現地等でどれだけ充実した生活を送ってきたかを知る指標として、英語力を重要視する場合が多いです。
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-private-school-inn-content-thumbnail">
                    <div class="thumbnail-list d-fl">
                        <a href="<?php echo esc_html( home_url('/') ) ?>thorough-analysis/entry-exams/" class="thumbnail-box">
                            <article>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/analyze/img01.png" alt="" class="">
                                </figure>
                                <h3>入試について</h3>
                            </article>
                        </a>
                        <a href="<?php echo esc_html( home_url('/') ) ?>thorough-analysis/private-school/" class="thumbnail-box">
                            <article>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/analyze/img02.png" alt="" class="">
                                </figure>
                                <h3>市立中って</h3>
                            </article>
                        </a>
                        <a href="<?php echo esc_html( home_url('/') ) ?>" class="thumbnail-box">
                            <article>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/analyze/img03.png" alt="" class="">
                                </figure>
                                <h3>帰国性受入校</h3>
                            </article>
                        </a>
                        <a href="<?php echo esc_html( home_url('/') ) ?>" class="thumbnail-box">
                            <article>
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/analyze/img04.png" alt="" class="">
                                </figure>
                                <h3>オンライン学校説明会</h3>
                            </article>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();