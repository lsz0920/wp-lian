<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="mv" class="l-mv">
        <div class="l-mv-inn">
            <div class="l-mv-inn-fl d-fl">
                <figure>
                    <img src="<?php echo get_template_directory_uri(); ?>/img/top/mv-img.jpg" alt="image" class="pc">
                    <img src="<?php echo get_template_directory_uri(); ?>/img/top/mv-bg-sp.png" alt="image" class="sp">
                </figure>
                <div class="l-mv-inn-info">
                    <div class="l-mv-inn-info-text">
                        <h2>
                            <span>海外にお住まいの</span>
                            <span>全ての子供たちのための</span>
                            <span>オンラインスクール</span>
                        </h2>
                        <div class="button">
                            <a href="<?php echo esc_html( home_url('/') ) ?>free-trial/" rel="noreferrer">無料体験レッスン</a>
                        </div>
                    </div>
                    <div class="latest-wrap">
                        <?php
                            $args = array(
                                'posts_per_page' => 1,
                                'post_type' => 'news'
                            );
                            $wp_query = new WP_Query($args);
                            if($wp_query->have_posts()):while ($wp_query->have_posts()) : $wp_query->the_post(); ?>
                        <div class="latest-news">
                            <a href="<?php the_permalink(); ?>">
                                <time><?php the_time('Y.m.d'); ?></time>
                                <p>
                                    <?php
                                        if(mb_strlen($post->post_title, 'UTF-8')>27){
                                            $title= mb_substr($post->post_title, 0, 27, 'UTF-8');
                                            echo $title.'…';
                                            }else{
                                                echo $post->post_title;
                                        }
                                    ?>
                                </p>
                            </a>
                        </div>
                        <?php endwhile;endif; ?>
                    </div>
                </div>
            </div>
            <div class="l-mv-inn-slider d-fl">
                <article>
                    <a href="">
                        <div class="img img01"><img src="<?php echo get_template_directory_uri(); ?>/img/top/loop01.png"
                                alt="img"></div>
                        <h3><span>マンツーマン</span></h3>
                        <p>マンツーマンの授業だから、<br /> 自分で聞いて、自分で考えて、
                            <br /> 自分で答える。授業を受ける
                            <br /> 意識が変わります。
                        </p>
                    </a>
                </article>
                <article>
                    <a href="">
                        <div class="img img02"><img src="<?php echo get_template_directory_uri(); ?>/img/top/loop02.png"
                                alt="img"></div>
                        <h3><span>担任制</span></h3>
                        <p>マンツーマンの授業だから、<br /> 自分で聞いて、自分で考えて、
                            <br /> 自分で答える。授業を受ける
                            <br /> 意識が変わります。
                        </p>
                    </a>
                </article>
                <article>
                    <a href="">
                        <div class="img img03"><img src="<?php echo get_template_directory_uri(); ?>/img/top/loop03.png"
                                alt="img"></div>
                        <h3><span>15年以上の経験</span></h3>
                        <p>マンツーマンの授業だから、<br /> 自分で聞いて、自分で考えて、
                            <br /> 自分で答える。授業を受ける
                            <br /> 意識が変わります。
                        </p>
                    </a>
                </article>
                <article>
                    <a href="">
                        <div class="img img04"><img src="<?php echo get_template_directory_uri(); ?>/img/top/loop04.png"
                                alt="img"></div>
                        <h3><span>プロの講師</span></h3>
                        <p>マンツーマンの授業だから、<br /> 自分で聞いて、自分で考えて、
                            <br /> 自分で答える。授業を受ける
                            <br /> 意識が変わります。
                        </p>
                    </a>
                </article>
                <article>
                    <a href="">
                        <div class="img img05"><img src="<?php echo get_template_directory_uri(); ?>/img/top/loop05.png"
                                alt="img"></div>
                        <h3><span>入会金無料</span></h3>
                        <p>マンツーマンの授業だから、<br /> 自分で聞いて、自分で考えて、
                            <br /> 自分で答える。授業を受ける
                            <br /> 意識が変わります。
                        </p>
                    </a>
                </article>
            </div>
        </div>
    </div>
    <div id="course" class="l-course">
        <div class="course-inn">
            <div class="course-inn-ttl main-ttl">
                <h2><span class="color-blue">C</span>OURSE</h2>
                <h3>コース紹介</h3>
            </div>
            <div class="course-inn-content">
                <div class="course-list d-fl">
                    <article class="">
                        <h2>永住されているお子様向け</h2>
                        <h3><span>日本語が苦手</span><span>日本語の読み書きを習得</span><span>JLPTを目指す</span><span>AP Japanese対策</span>
                        </h3>
                        <div class="course-thumbImg">
                            <figure>
                                <img src="<?php echo get_template_directory_uri(); ?>/img/course/course-01.png" alt="">
                            </figure>
                            <div class="course-moreBtn">
                                <div class="course-moreBtn-01">
                                    <a href="" rel="alternate">more</a>
                                </div>
                                <div class="course-moreBtn-02">
                                    <a href="<?php echo esc_html( home_url('/') ) ?>free-trial/" rel="alternate">無料体験</a>
                                </div>
                            </div>
                        </div>
                        <p>お子様の年齢や学年に関係なく、一人一人のお子さんに合わせた日本語学習を行っていきます。</p>
                    </article>
                    <article class="">
                        <h2>駐在者のお子様</h2>
                        <h3><span>日本に帰国後ついていけるように</span><span>算数をもっと</span><span>受験対策をしたい</span></h3>
                        <div class="course-thumbImg">
                            <figure>
                                <img src="<?php echo get_template_directory_uri(); ?>/img/course/course-02.png" alt="">
                            </figure>
                            <div class="course-moreBtn">
                                <div class="course-moreBtn-01">
                                    <a href="" rel="alternate">more</a>
                                </div>
                                <div class="course-moreBtn-02">
                                    <a href="<?php echo esc_html( home_url('/') ) ?>free-trial/" rel="alternate">無料体験</a>
                                </div>
                            </div>
                        </div>
                        <p>近くに補習校がない、又はお子様に合わせた教育を考えている方へ、日本の小学校、中学校と同等の学習指導を。</p>
                    </article>
                    <article class="">
                        <h2>帰国生受験対策</h2>
                        <h3><span>帰国生受験対策</span><span>作文、小論文指導</span><span>英作文指導</span><span>英語対策</span></h3>
                        <div class="course-thumbImg">
                            <figure>
                                <img src="<?php echo get_template_directory_uri(); ?>/img/course/course-03.png" alt="">
                            </figure>
                            <div class="course-moreBtn">
                                <div class="course-moreBtn-01">
                                    <a href="" rel="alternate">more</a>
                                </div>
                                <div class="course-moreBtn-02">
                                    <a href="<?php echo esc_html( home_url('/') ) ?>free-trial/" rel="alternate">無料体験</a>
                                </div>
                            </div>
                        </div>
                        <p>中学、高校の帰国生受験の対策はもちろん、帰国生入試の調査から行っております。</p>
                    </article>
                    <article class="">
                        <h2>帰国後の英語</h2>
                        <h3><span>英語力の維持</span><span>帰国生入試対策</span><span>英文エッセイ　英検　TOEFL対策</span></h3>
                        <div class="course-thumbImg">
                            <figure>
                                <img src="<?php echo get_template_directory_uri(); ?>/img/course/course-04.png" alt="">
                            </figure>
                            <div class="course-moreBtn">
                                <div class="course-moreBtn-01">
                                    <a href="" rel="alternate">more</a>
                                </div>
                                <div class="course-moreBtn-02">
                                    <a href="<?php echo esc_html( home_url('/') ) ?>free-trial/" rel="alternate">無料体験</a>
                                </div>
                            </div>
                        </div>
                        <p>海外からの帰国後、お子様が身につけた英語能力をキープ、向上させるため、Best Seminarでは「帰国子女のための英語授業」を始めました。</p>
                    </article>
                </div>
            </div>
        </div>
    </div>
    <div id="blogs" class="l-blogs">
        <div class="blogs-inn">
            <div class="blogs-inn-content">
                <div class="blogs-list d-fl">
                    <?php
                        $blogs = array(
                            'posts_per_page' => 6,
                            'post_type' => 'blog'
                        );
                        $wp_query = new WP_Query($blogs);
                        if($wp_query->have_posts()):while ($wp_query->have_posts()) : $wp_query->the_post(); 
                    ?>
                    <article class="">
                        <div class="blog-thumbImg">
                            <figure>
                                <?php echo get_the_post_thumbnail(); ?>
                            </figure>
                        </div>
                        <time><?php the_time('Y.m.d'); ?></time>
                        <h2><?php the_title(); ?></h2>
                        <?php the_excerpt(); ?>
                        <div class="blog-moreBtn">
                            <a href="<?php the_permalink(); ?>" rel="alternate">view more</a>
                        </div>
                    </article>
                    <?php endwhile; endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div id="contact" class="l-contact">
        <div class="contact-inn">
            <div class="contact-inn-ttl main-ttl">
                <h2 data-splitting><span class="color-blue">C</span>ONTACT</h2>
                <h3>お問い合わせ</h3>
            </div>
            <div class="contact-inn-content d-fl">
                <div class="contact-btn-form">
                    <p>メールでのお問い合わせ</p>
                    <a href="<?php echo esc_html( home_url('/') ) ?>contact/" rel="alternate">お問い合わせフォーム</a>
                </div>
                <div class="contact-btn-line">
                    <p>Line でのお問い合わせ</p>
                    <a href="" rel="alternate">
                        <span>
                            <img src="<?php echo get_template_directory_uri(); ?>/img/top/line.png" alt="">
                        </span>お問い合わせフォーム
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div id="faq" class="l-faq">
        <div class="faq-inn">
            <div class="faq-inn-ttl main-ttl">
                <h2><span class="color-blue">F</span>AQ</h2>
                <h3>よくある質問</h3>
            </div>
            <div class="faq-inn-content">
                <?php
                    $args = array(
                    'post_type'         => 'faq',
                    'posts_per_page'    => 3,
                    'exclude'           => ''
                    );
                    $loop = new WP_Query($args); 
                ?>
                <div class="faq-list">
                    <?php while($loop->have_posts()): $loop->the_post(); ?>
                    <section class="faq-list-wrap faq-list-01">
                        <h2><?php echo get_the_title(); ?></h2>
                        <div class="faq-list-inner">
                            <?php $fields = CFS()->get('faq_loop');?>
                                <?php if ($fields):?>
                                <?php foreach ( $fields as $field ):?>
                                <dl>
                                    <?php if($field['question'] != ''): ?>
                                        <dd><?php echo $field['question'];?></dd>
                                    <?php endif; ?>
                                    <?php if($field['answer'] != ''): ?>
                                        <dt><?php echo $field['answer'];?></dt>
                                    <?php endif; ?>
                                </dl>
                            <?php endforeach; endif; ?>
                        </div>
                    </section>
                    <?php endwhile;?>
                </div>
                <div class="faq-moreBtn">
                    <a href="<?php echo esc_html( home_url('/') ) ?>faq/">MORE</a>
                </div>
            </div>
        </div>
    </div>
    <div id="review" class="l-review">
        <div class="review-inn">
            <div class="review-inn-ttl main-ttl">
                <h2><span class="color-blue">R</span>EVIEW</h2>
                <h3>ユーザレビュー</h3>
            </div>
            <div class="review-inn-content">
                <div class="review-list">
                    <?php
                        $reviews = array(
                            'posts_per_page' => -1,
                            'post_type' => 'review'
                        );
                        $wp_query = new WP_Query($reviews);
                        if($wp_query->have_posts()):while ($wp_query->have_posts()) : $wp_query->the_post(); 
                    ?>
                    <article class="review-list-wrap review-list-01 d-fl">
                        <div class="review-list-thumb">
                            <figure>
                                <?php echo get_the_post_thumbnail(); ?>
                            </figure>
                            <h2><?php the_title();?></h2>
                            <?php if(CFS()->get('place')): ?><h3><?php echo CFS()->get('place'); ?></h3><?php endif; ?>
                        </div>
                        <div class="review-list-info">
                            <?php the_content(); ?>
                        </div>
                    </article>
                    <?php endwhile; endif; ?>
                </div>
                <div class="review-btn">
                    <a href="<?php echo esc_html( home_url('/') ) ?>review" rel="alternate">more</a>
                </div>
            </div>
        </div>
    </div>
    <div id="scale" class="l-scale">
        <div class="scale-inn">
            <div class="scale-inn-ttl main-ttl">
                <h2><span class="color-blue">R</span>IEW POINT<br class="sp"> FROM STUDENT</h2>
                <h3>生徒さんが見たベストゼミナールの特徴</h3>
            </div>
            <div class="scale-inn-content">
                <div class="scale-list">
                    <div class="scale-ratio">
                        <img src="<?php echo get_template_directory_uri(); ?>/img/top/scale.png" alt="">
                    </div>
                    <div class="scale-wrap">
                        <ul class="d-fl">
                            <li class="color-red">日本語がうまく<br>なった</li>
                            <li class="color-red">ひらがなができた</li>
                            <li class="color-red">手紙がかけるよう<br>になった</li>
                            <li class="color-red">学力が伸びた</li>
                            <li class="color-red">成績があがった</li>
                            <li class="color-red">成績があがった</li>
                            <li class="color-red">算数の<br>ちからがついた</li>
                            <li class="color-red">算数の<br>ちからがついた</li>
                            <li class="color-red">日本語での会話が<br>多くなった</li>
                            <li class="color-red">日本語がうまく<br>なった</li>
                            <li class="color-orange">授業が<br>分かりやすい</li>
                            <li class="color-orange">授業が<br>分かりやすい</li>
                            <li class="color-orange">成績があがった</li>
                            <li class="color-orange">算数の<br>ちからがついた</li>
                            <li class="color-orange">先生が優しい</li>
                            <li class="color-orange">先生が優しい</li>
                            <li class="color-orange">先生が優しい</li>
                            <li class="color-orange">女性の先生</li>
                            <li class="color-green">日本語での会話が<br>多くなった</li>
                            <li class="color-green">学力が伸びた</li>
                            <li class="color-green">日本語がうまく<br>なった</li>
                            <li class="color-green">ひらがなができた</li>
                            <li class="color-green">手紙がかけるよう<br>になった</li>
                            <li class="color-green">学力が伸びた</li>
                            <li class="color-green">手紙がかけるよう<br>になった</li>
                            <li class="color-green">成績があがった</li>
                            <li class="color-green">算数の<br>ちからがついた</li>
                            <li class="color-blue">算数の<br>ちからがついた</li>
                            <li class="color-blue">日本語での会話が<br>多くなった</li>
                            <li class="color-blue">成績があがった<br><br>日本語がうまく<br>なった</li>
                            <li class="color-blue">授業が<br>分かりやすい</li>
                            <li class="color-blue">授業が<br>分かりやすい</li>
                            <li class="color-black">成績があがった</li>
                            <li class="color-black">算数の<br>ちからがついた</li>
                            <li class="color-black">先生が優しい</li>
                            <li class="color-black">先生が優しい</li>
                            <li class="color-black">先生が優しい</li>
                            <li class="color-black">女性の先生</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="banner" class="l-contactbnr">
        <div class="l-contactbnr-inn">
            <h2><span>無料体験レッスン受付中！</span></h2>
            <p>ベストゼミナールでは、<br class="sp">安心して受講していただくために、<br class="pc" />実際の授業を<br
                    class="sp"><strong>1ヶ月間無料</strong>で体験していただけます。</p>
            <div class="banner-btn d-fl">
                <div class="banner-btn-l">
                    <a href="<?php echo esc_html( home_url('/') ) ?>free-trial/" rel="alternate">1ヶ月無料体験レッスン</a>
                </div>
                <div class="banner-btn-r">
                    <a href="<?php echo esc_html( home_url('/') ) ?>document-request/" rel="alternate">
                    <span>
                        <img src="<?php echo get_template_directory_uri(); ?>/img/common/doc-icon.png" alt="" class="doc-icon">
                        <img src="<?php echo get_template_directory_uri(); ?>/img/common/doc-icon-hover.png" alt="" class="doc-icon-hover">
                    </span>資料請求はこちら</a>
                </div>
            </div>
        </div>
    </div>
</main>
<!-- #main -->

<?php
get_footer();