<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>S</span>CHEDULE</h2>
                <h3 class="jp-ttl">休校日カレンダー</h3>
            </div>
            <div class="sl-subpage-list">
                    <ul>
                        <li><a href="#">模擬試験</a></li>
                        <li><a href="#">教育セミナートップ</a></li>
                        <li><a href="#">入試実績</a></li>
                        <li><a href="#">子供新聞</a></li>
                        <li><a href="#">Facebook</a></li>
                        <li><a href="#">Blog</a></li>
                    </ul>
            </div>
        </div>
        <div class="sl-subpage-schedule">
            <div class="sl-subpage-schedule-inn inner">
                <div class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
                    <?php if (function_exists('bcn_display')) {
                        bcn_display();
                    }?>
                </div>
                <div class="sl-subpage-schedule-inn-content">
                    <p>
                    第5週目はベストゼミナールの休校日になります。<br>
                    1月、5月、8月は月初または中旬を休校日としています。
                    </p>
                    <div class="sl-subpage-schedule-inn-content-inner">
                        <div class="schedule-years d-fl">
                            <p class="date start-year"><span class="year">2021</span>年<span class="month">12</span>月</p>
                            <p class="date end-year"><span class="year">2022</span>年<span class="month">12</span>月</p>
                        </div>
                        
                        <?php echo do_shortcode( '[wp_school_calendar]' ); ?>
                    </div>
                    
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();
