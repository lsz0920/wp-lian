<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

	<main id="primary" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>G</span>UIDANCE</h2>
                <h3 class="jp-ttl">永住者向け</h3>
            </div>
            <div class="sl-subpage-list">
                <ul>
                    <li><a href="#">模擬試験</a></li>
                    <li><a href="#">教育セミナートップ</a></li>
                    <li><a href="#">入試実績</a></li>
                    <li><a href="#">子供新聞</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </div>
        </div>
        <div class="sl-guide">
            <div class="sl-guide-inn inner">
                <div class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
                    <?php if (function_exists('bcn_display')) {
                            bcn_display();
                    }?>
                </div>
                <ul class="sl-guide-inn-list d-fl">
                    <li><a href="#read-write">読み書きをしっかり習得 </a></li>
                    <li><a href="#notgood-jp">日本語が苦手なお子様 </a></li>
                    <li><a href="#young-child">6歳未満のお子様</a></li>
                    <li><a href="#ap-japanense">AP Japanese対策</a></li>
                    <li><a href="#jlpt">JLPT対策</a></li>
                </ul>
                <div class="sl-guide-inn-content">
                    <div class="guide-wrap">
                        <div class="guide-inn box-shadow" id="read-write">
                            <h3 class="guide-ttl">読み書きをしっかり習得</h3>
                            <div class="guide-inn-detail">
                                <div class="guide-inn-fl d-fl">
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-01.png" alt="image">
                                    </figure>
                                    <div class="guide-schedule">
                                        <dl>
                                            <dt>
                                                小学2年生以下<span>（ 40分間授業s× 4回 ）</span>
                                            </dt>
                                            <dd>
                                                128<span>ドル〜/月</span>
                                            </dd>
                                        </dl>
                                        <dl>
                                            <dt>
                                                小学3年生以下<span>（ 50分間授業× 4回 ）</span>
                                            </dt>
                                            <dd>
                                                130<span>ドル〜/月</span>
                                            </dd>
                                        </dl>
                                        <div class="guide-link">
                                            <a href="<?php echo esc_html( home_url('/') ) ?>">授業料をもっと詳しく</a>
                                        </div>
                                        <div class="trial-btn">
                                            <a href="<?php echo esc_html( home_url('/') ) ?>">無料体験レッスン</a>
                                        </div>
                                    </div>
                                </div>
                                <p>
                                    海外にお住まいで、お子様のいらっしゃる方の気がかりの一つは、お子様の日本語力ではないでしょうか。特に小学生以降になりますと、日本在住で国語教育を受けている子供とは日本語読み書きの習得度に大きな差ができてしまいます。また、家庭など限られた環境の中だけで日本語の保持をしようとすると、日本語表現が限定的になり、多様な語彙の使い分けや漢字習得がむずかしくなる傾向にあります。人間の場合、通常5、6歳くらいまでに自然習得した言語が母語となります。外国語として身につける言語とは違って、母語には脳が感覚的に文法を認識し、ごく自然に言語を習得していく特徴があります。その後、より複雑な語彙の使い分けや難解な読み書きの習得によって母語をブラッシュアップし、12歳くらいまでに言語としての完成期を迎えます。日本にいるお子様の場合、このブラッシュアップが小学校での国語教育にあたります。ベストゼミナールでは、年齢や学年に関係なく、お子様一人一人の日本語レベルに合わせ、日本の国語教育と同等の授業を行なっています。日本語のブラッシュアップとして、小学校で習得するレベルの平仮名、カタカナ、漢字の読み書きを存分に習得してください。<br>
                                    ベストゼミナールの授業は、多人数で受けるクラス授業とは異なり、日本語講師とのマンツーマンによるオンラインレッスンです。先生の日本語を自分自身で聞いて、考えて、返答せざるを得ない状況に緊張感が生まれ、お子様の日本語に対する意識が変わります。その効果として、読み書き以上に子供の日本語会話力が飛躍的に向上します。会話は、お子様自身が日本語を上手くなる実感を得やすく、以降のやる気にも結びついていきます。<br>
                                    さらにベストゼミナールでは、お子様の日本語への興味を損なわないよう楽しく勉強できる持続可能な日本語学習を目指しています。教科書や教科書準拠、準拠教材のほかにも、日本のマンガやお子様の興味ある分野の副教材を使います。お子様が自ら進んで日本語の本を手にとるような読書習慣の形成を目指します。<br>
                                    海外在住のお子様は日本語に接する機会が限られております。そのため一人一人のお子様のためにカスタマイズした日本語学習を、マンツーマンで行う担任制が大切だとベストゼミナールでは考えています。海外で育ったお子様にとって、母語を2つもつバイリンガルは特殊能力であり、将来の可能性を大きく広げるものです。
                                </p>
                                <ul class="guide-step d-fl">
                                    <li><a href="">体験から授業までの流れ</a></li>
                                    <li><a href="">授業の進め方</a></li>
                                    <li><a href="">講師の紹介</a></li>
                                </ul>
                                <div class="jp-education">
                                   <h3 class="guide-sub-ttl">継承語としての日本語教育</h3>
                                   <div class="jp-education-inn d-fl">
                                       <article>
                                           <h4>日本語教育</h4>
                                           <figure>
                                               <img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-img01.png" alt="guide image">
                                           </figure>
                                           <div class="view-btn">
                                                <a href="">view more</a>
                                           </div>
                                       </article>
                                       <article>
                                           <h4>ベストこども新聞<span>/</span>生徒が書いた新聞です</h4>
                                           <figure>
                                               <img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-img01.png" alt="guide image">
                                           </figure>
                                           <div class="view-btn">
                                                <a href="">view more</a>
                                           </div>
                                           
                                       </article>
                                   </div>
                                </div>
                                <div class="guide-price">
                                    <div class="guide-price-ttl">
                                        <h2 class="eng-ttl"><span>P</span>RICE</h2>
                                        <h3 class="jp-ttl">料金</h3>
                                    </div>
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>学年</th>
                                                <th>授業時間</th>
                                                <th>週1回（月4回）</th>
                                                <th>週2回（月8回）</th>
                                                <th>週3回（月12回）</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>小学2年生以下</td>
                                                <td>40分</td>
                                                <td>$128</td>
                                                <td>$245</td>
                                                <td>$360</td>
                                            </tr>
                                            <tr>
                                                <td>小学3～6年生</td>
                                                <td>50分</td>
                                                <td>$133</td>
                                                <td>$255</td>
                                                <td>$370</td>
                                            </tr>
                                            <tr>
                                                <td>中学生</td>
                                                <td>50分</td>
                                                <td>$138</td>
                                                <td>$265</td>
                                                <td>$385</td>
                                            </tr>
                                            <tr>
                                                <td>高校生</td>
                                                <td>50分</td>
                                                <td>$150</td>
                                                <td>$285</td>
                                                <td>$410</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <p class="bottom-txt">
                                    表示料金は米ドル(USD)です。<a href="">（USドル以外の通貨はこちら）</a><br>
                                    中学生以上で生徒の受講レベルが小学生レベルの場合は小学生料金を適用します。<br>
                                    毎授業後、保護者の方にメールで授業報告をいたします。<br>
                                    授業料金は輸出扱いになるため、消費税(Sales Tax)はかかりません。 
                                    </p>
                                    <div class="price-flow d-fl">
                                        <div class="flow-inn d-fl">
                                            <span class="icon"><img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-ico01.svg" alt="icon"></span>
                                            <div class="flow-txt">
                                                <h4>入会金0円</h4>
                                                <p>入会金はありません。</p>
                                            </div>
                                        </div>
                                        <div class="flow-inn d-fl">
                                            <span class="icon"><img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-ico02.svg" alt="icon"></span>
                                            <div class="flow-txt">
                                                <h4>月謝制</h4>
                                                <p>最低契約期間はありません。<br>
                                                    月毎であれば、<br>
                                                    いつでも退会できます。
                                                </p>
                                            </div>
                                        </div>
                                        <div class="flow-inn d-fl">
                                            <span class="icon"><img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-ico03.svg" alt="icon"></span>
                                            <div class="flow-txt">
                                                <h4>兄弟割引</h4>
                                                <p>ご兄弟割引きで<br>
                                                    みなさまの授業料が<br>
                                                    <span>ずっと5％割引</span>になります。
                                                </p>
                                            </div>
                                        </div>
                                        <div class="flow-inn d-fl">
                                            <span class="icon"><img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-ico04.svg" alt="icon"></span>
                                            <div class="flow-txt">
                                                <h4>ご兄弟同時入会割引</h4>
                                                <p>お二人目の、<br>
                                                  初月<span>50ドル割引</span>に<br>
                                                    なります。
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="guide-inn box-shadow" id="notgood-jp">
                            <h3 class="guide-ttl">日本が苦手な方、ゼロから習いたい方<span>（日本語の理解度が5％から40％くらいの方）</span></h3>
                            <div class="guide-inn-detail">
                                <div class="guide-inn-fl d-fl">
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-02.png" alt="image">
                                    </figure>
                                    <div class="guide-schedule">
                                        <dl>
                                            <dt>
                                                40分間授業
                                            </dt>
                                            <dd>
                                                135<span>ドル〜/月</span>
                                            </dd>
                                        </dl>
                                        <div class="guide-link">
                                            <a href="<?php echo esc_html( home_url('/') ) ?>">授業料をもっと詳しく</a>
                                        </div>
                                        <div class="trial-btn">
                                            <a href="<?php echo esc_html( home_url('/') ) ?>">無料体験レッスン</a>
                                        </div>
                                    </div>
                                </div>
                                <p>
                                お母様がお話しする日本語の4割がわからないお子様には、特別な方法での日本語教育が必要になります。<br>
                                ・日本語での発話がない<br>
                                ・一語文でしか日本語を話せない<br>
                                ・お母様が話す簡単な日本語のほんの一部しかわからない<br>
                                ・日本語の語彙が少ない<br>
                                ベストゼミナールでは、このような生徒様のために、研修を受けた講師がマンツーマンで日本語授業を行います。<br>
                                マンツーマン授業を行う際に重要なのは、先生の話す日本語をお子様自身が自分で聞いて、自分で考え、自分で答えるという意識を芽生えさせることです。もちろん、初めて日本語を勉強するお子様や、日本語の基礎から勉強をはじめるお子様は、日本語だけでコミュニケーションがとれない場合がほとんどになりますが、そういったケースにも対応できる経験豊富な講師陣が多数在籍しております。教師の経験をもつものやキャリアの長いものもおりますので、安心しておまかせください。<br>
                                お子様の集中力が途切れないよう、イラストや折り紙を使ったり、一緒に絵本を読んだりしながら、日本語を日本語で教えるPure Japanese Teaching法という手法で日本語教育を行います。はじめは先生の話す日本語が正しく聞けず、内容がほとんど理解できなかったお子様でも、適正な手順を踏んだ授業を受けることで、3か月から6か月のうちに先生の発話がほぼ理解できるようになり、日本語だけでのコミュニケーションも可能になります。お子様自身にも日本語が上手になる実感が沸き、さらなる向上心につながっていきます。<br><br>
                                重要なポイント<br>
                                日本語だけで授業を行う　→　日本語を話すこと・聞くことの理由付け、意識の変容につながります。<br>
                                毎回同じ先生が行う　→　信頼関係をつくり　継続的な日本語指導ができます。<br>
                                楽しく日本語を学ぶ、日本語で遊ぶ　→　日本語の言語発達につながります。<br><br>
                                お子様の日本語の理解度が4割以上ある場合は「読み書きをしっかり習得コース」をご覧ください。<br>
                                また、ご自身で判断がつかない場合は、ベストゼミナールにお問い合わせください。体験授業の前にご相談のうえ学力チェックを行い、適切な方法をご提案いたします。
                                </p>
                                <ul class="guide-step d-fl">
                                    <li><a href="">体験から授業までの流れ</a></li>
                                    <li><a href="">授業の進め方</a></li>
                                    <li><a href="">講師の紹介</a></li>
                                </ul>
                                <div class="jp-education">
                                   <h3 class="guide-sub-ttl">継承語としての日本語教育</h3>
                                   <div class="jp-education-inn d-fl">
                                       <article>
                                           <h4>日本語教育</h4>
                                           <figure>
                                               <img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-img01.png" alt="guide image">
                                           </figure>
                                           <div class="view-btn">
                                                <a href="">view more</a>
                                           </div>
                                       </article>
                                       <article>
                                           <h4>ベストこども新聞<span>/</span>生徒が書いた新聞です</h4>
                                           <figure>
                                               <img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-img01.png" alt="guide image">
                                           </figure>
                                           <div class="view-btn">
                                                <a href="">view more</a>
                                           </div>
                                           
                                       </article>
                                   </div>
                                </div>
                                <div class="guide-price">
                                    <div class="guide-price-ttl">
                                        <h2 class="eng-ttl"><span>P</span>RICE</h2>
                                        <h3 class="jp-ttl">料金</h3>
                                    </div>
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>授業時間</th>
                                                <th>週1回（月4回）</th>
                                                <th>週2回（月8回）</th>
                                                <th>週3回（月12回）</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>40分</td>
                                                <td>$138</td>
                                                <td>$255</td>
                                                <td>$370</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <p class="bottom-txt">
                                    表示料金は米ドル(USD)です。<a href="">（USドル以外の通貨はこちら）</a><br>
                                    中学生以上で生徒の受講レベルが小学生レベルの場合は小学生料金を適用します。<br>
                                    毎授業後、保護者の方にメールで授業報告をいたします。<br>
                                    授業料金は輸出扱いになるため、消費税(Sales Tax)はかかりません。 
                                    </p>
                                    <div class="price-flow d-fl">
                                        <div class="flow-inn d-fl">
                                            <span class="icon"><img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-ico01.svg" alt="icon"></span>
                                            <div class="flow-txt">
                                                <h4>入会金0円</h4>
                                                <p>入会金はありません。</p>
                                            </div>
                                        </div>
                                        <div class="flow-inn d-fl">
                                            <span class="icon"><img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-ico02.svg" alt="icon"></span>
                                            <div class="flow-txt">
                                                <h4>月謝制</h4>
                                                <p>最低契約期間はありません。<br>
                                                    月毎であれば、<br>
                                                    いつでも退会できます。
                                                </p>
                                            </div>
                                        </div>
                                        <div class="flow-inn d-fl">
                                            <span class="icon"><img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-ico03.svg" alt="icon"></span>
                                            <div class="flow-txt">
                                                <h4>兄弟割引</h4>
                                                <p>ご兄弟割引きで<br>
                                                    みなさまの授業料が<br>
                                                    <span>ずっと5％割引</span>になります。
                                                </p>
                                            </div>
                                        </div>
                                        <div class="flow-inn d-fl">
                                            <span class="icon"><img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-ico04.svg" alt="icon"></span>
                                            <div class="flow-txt">
                                                <h4>ご兄弟同時入会割引</h4>
                                                <p>お二人目の、<br>
                                                  初月<span>50ドル割引</span>に<br>
                                                    なります。
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="guide-inn box-shadow" id="young-child">
                            <h3 class="guide-ttl">6歳未満のお子様</h3>
                            <div class="guide-inn-detail">
                                <div class="guide-inn-fl d-fl">
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-03.png" alt="image">
                                    </figure>
                                    <div class="guide-schedule">
                                        <dl>
                                            <dt>
                                                40分間授業
                                            </dt>
                                            <dd>
                                                135<span>ドル〜/月</span>
                                            </dd>
                                        </dl>
                                        <div class="guide-link">
                                            <a href="<?php echo esc_html( home_url('/') ) ?>">授業料をもっと詳しく</a>
                                        </div>
                                        <div class="trial-btn">
                                            <a href="<?php echo esc_html( home_url('/') ) ?>">無料体験レッスン</a>
                                        </div>
                                    </div>
                                </div>
                                <p>
                                言語の習得にとってもっとも大事なのは、４、５、６歳の時期です。人間は５歳までに自然習得した言語がネイティブランゲージとなり、外国にいる子供であっても、この幼児期に日本語話者と日本語のコミュニケーションをとる機会をどれだけもつかによって、母語としての日本語の位置づけが決まってきます。<br>
                                この時期のお子様には、勉強というよりも、日本語を話す、日本語を聞く、日本語を書くという３要素を駆使して「日本語を使う」ことに重点をおいた授業を行います。はじめて日本語にふれるお子様にも、基礎の日本語が身につくようしっかりとサポートさせていただきます。<br>
                                小さいお子様ですと、同じことを１５分以上行うと飽きてしまうことも踏まえながら、子供向けの日本語会話を意識した授業を行います。<br><br>
                                言語習得期のお子様にとって、ご家庭で日本語を使う機会がとても重要になります。もっとも効果的なのは、One Person One Language 制の実践です。たとえば、お父様とは英語で、お母様とは必ず日本語で話すというルールをつくると、バイリンガル教育に有効であるとされています。<br>
                                特に日本語より英語等日本語以外の言語の方が得意なお子様は、理由がない限り日常的に使っている以外の言語を使いたがりません。そこで「お母さんとは日本語で話すものである」という理由付けが必要になるのです。<br>
                                とはいえ、なかなか急には日本語で話したい、日本語で聞きたいといった気持ちになれないことが多いと思います。そのような場合は、まず、毎日20分間「日本語だけの時間」をつくってみてください。夜寝る前など、いちばん気持ちが安定している時間に、一緒に絵本を見たり、読み聞かせたりしながら、日本語での語りかけを行ってください。日本語を上手に話せない、聞けないお子様にも効果のある方法です。<br>
                                さらに「今日の授業でどんな言葉を習ったの？」「この漢字読める？」等日本語で尋ね、やさしい日本語でかまいませんので、お子様とお話ししてみてください。ベストゼミナールの授業だけでは日本語の使用量が十分とはいえませんので、お子様が自然に日本語を話したい、聞きたいと思えるようになるまで、ご家族みなさまで日本語サポートを実行することが大切です。<br>
                                ベストゼミナールでは、5歳以上のお子様から学んでいただける日本語教育の授業を行っています。毎週決まった時間に、ご家族以外の先生と日本語学習することがお子様のライフスタイルの一部になるよう、楽しみながら日本語を習得してみてください。
                                </p>
                                <ul class="guide-step d-fl">
                                    <li><a href="">体験から授業までの流れ</a></li>
                                    <li><a href="">授業の進め方</a></li>
                                    <li><a href="">講師の紹介</a></li>
                                </ul>
                                <div class="jp-education">
                                   <h3 class="guide-sub-ttl">継承語としての日本語教育</h3>
                                   <div class="jp-education-inn d-fl">
                                       <article>
                                           <h4>日本語教育</h4>
                                           <figure>
                                               <img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-img01.png" alt="guide image">
                                           </figure>
                                           <div class="view-btn">
                                                <a href="">view more</a>
                                           </div>
                                       </article>
                                       <article>
                                           <h4>ベストこども新聞<span>/</span>生徒が書いた新聞です</h4>
                                           <figure>
                                               <img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-img01.png" alt="guide image">
                                           </figure>
                                           <div class="view-btn">
                                                <a href="">view more</a>
                                           </div>
                                           
                                       </article>
                                   </div>
                                </div>
                                <div class="guide-price">
                                    <div class="guide-price-ttl">
                                        <h2 class="eng-ttl"><span>P</span>RICE</h2>
                                        <h3 class="jp-ttl">料金</h3>
                                    </div>
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>学年</th>
                                                <th>授業時間</th>
                                                <th>週1回（月4回）</th>
                                                <th>週2回（月8回）</th>
                                                <th>週3回（月12回）</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>小学2年生以下</td>
                                                <td>40分</td>
                                                <td>$128</td>
                                                <td>$245</td>
                                                <td>$360</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <p class="bottom-txt">
                                    表示料金は米ドル(USD)です。<a href="">（USドル以外の通貨はこちら）</a><br>
                                    中学生以上で生徒の受講レベルが小学生レベルの場合は小学生料金を適用します。<br>
                                    毎授業後、保護者の方にメールで授業報告をいたします。<br>
                                    授業料金は輸出扱いになるため、消費税(Sales Tax)はかかりません。 
                                    </p>
                                    <div class="price-flow d-fl">
                                        <div class="flow-inn d-fl">
                                            <span class="icon"><img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-ico01.svg" alt="icon"></span>
                                            <div class="flow-txt">
                                                <h4>入会金0円</h4>
                                                <p>入会金はありません。</p>
                                            </div>
                                        </div>
                                        <div class="flow-inn d-fl">
                                            <span class="icon"><img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-ico02.svg" alt="icon"></span>
                                            <div class="flow-txt">
                                                <h4>月謝制</h4>
                                                <p>最低契約期間はありません。<br>
                                                    月毎であれば、<br>
                                                    いつでも退会できます。
                                                </p>
                                            </div>
                                        </div>
                                        <div class="flow-inn d-fl">
                                            <span class="icon"><img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-ico03.svg" alt="icon"></span>
                                            <div class="flow-txt">
                                                <h4>兄弟割引</h4>
                                                <p>ご兄弟割引きで<br>
                                                    みなさまの授業料が<br>
                                                    <span>ずっと5％割引</span>になります。
                                                </p>
                                            </div>
                                        </div>
                                        <div class="flow-inn d-fl">
                                            <span class="icon"><img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-ico04.svg" alt="icon"></span>
                                            <div class="flow-txt">
                                                <h4>ご兄弟同時入会割引</h4>
                                                <p>お二人目の、<br>
                                                  初月<span>50ドル割引</span>に<br>
                                                    なります。
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="guide-inn box-shadow" id="jlpt">
                            <h3 class="guide-ttl">日本語試験対策</h3>
                            <div class="guide-inn-detail">
                                <div class="guide-inn-fl d-fl">
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-04.png" alt="image">
                                    </figure>
                                    <div class="guide-schedule">
                                        <dl>
                                            <dt>
                                                小学2年生以下<span>（ 40分間授業s× 4回 ）</span>
                                            </dt>
                                            <dd>
                                                128<span>ドル〜/月</span>
                                            </dd>
                                        </dl>
                                        <dl>
                                            <dt>
                                                小学3年生以下<span>（ 50分間授業× 4回 ）</span>
                                            </dt>
                                            <dd>
                                                130<span>ドル〜/月</span>
                                            </dd>
                                        </dl>
                                        <div class="guide-link">
                                            <a href="<?php echo esc_html( home_url('/') ) ?>">授業料をもっと詳しく</a>
                                        </div>
                                        <div class="trial-btn">
                                            <a href="<?php echo esc_html( home_url('/') ) ?>">無料体験レッスン</a>
                                        </div>
                                    </div>
                                </div>
                                <p>
                                    AP Japanese対策<br>
                                    AP Japaneseの日本語力のレベルは、だいたい小学4年生レベルといわれています。まずは、小学校4年生レベルの国語力の習得を目指しましょう。<br>
                                    4年生レベルの国語力があれば、次に日本語4技能 Listening Reading Writing Speakingのうち苦手分野を補強する対策をとります。<br>
                                    AP Japaneseにおいて特に事前の準備が必要になるのが、Writingと最後のPresentationです。Writingでは、決められた形式に沿った形で書く必要があるため、事前練習が不可欠です。また、Presentationは、日本文化を知らないと返答しづらい課題が多いので、日頃から日本文化にふれ、短時間で文章にまとめる技術を身につけておく必要があります。<br><br>
                                    ＪＬＰＴ（日本語能力検定試験）対策<br>
                                    JLPTは、国際交流基金が主催しているテストです。日本語能力試験として、世界的にもっとも広く認められており、お子様にとって生涯意義ある資格となるでしょう。<br>
                                    また、5段階のレベルテスト制ですので、日本語学習のマイルストーンとしてもいいですし、N5かN4から順に検定取得を目指せば、モチベーションのアップにもつながります。<br>
                                    N2のリスニングと文法については、日本在住の小学校2年生程度の日本語力があれば、ほぼ満点がとれるレベルですが、ネックになるのが漢字力といえます。合格を目指すには、下記の漢字力を身につける必要があります。<br>
                                </p>
                                <div class="jlpt-level">
                                    <p>漢字力</p>
                                    <dl>
                                        <dt>N5　100　　小2レベル</dt>
                                        <dd>N2　1000　 小6レベル</dd>
                                    </dl>
                                    <dl>
                                        <dt>N4　300　　小3レベル</dt>
                                        <dd>N1　2000　 中3レベル</dd>
                                    </dl>
                                    <dl>
                                        <dt>N3　600　　小4レベル</dt>
                                    </dl>
                                </div>
                                <p>海外在住のお子様でも、日本語補習校に通っていた場合であれば、少しの努力でN3かN2までの取得は可能です。海外においては、N2、そして難易度の高いN1の資格者は少なく、N2以上の資格取得は、企業の日本語能力判断基準として評価が高いため、就職の際に有利です。お子様の一生の財産にもなりますので、ぜひ資格取得を検討してみてください。</p>
                                <ul class="guide-step d-fl">
                                    <li><a href="">体験から授業までの流れ</a></li>
                                    <li><a href="">授業の進め方</a></li>
                                    <li><a href="">講師の紹介</a></li>
                                </ul>
                                <div class="jp-education">
                                   <h3 class="guide-sub-ttl">継承語としての日本語教育</h3>
                                   <div class="jp-education-inn d-fl">
                                       <article>
                                           <h4>日本語教育</h4>
                                           <figure>
                                               <img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-img01.png" alt="guide image">
                                           </figure>
                                           <div class="view-btn">
                                                <a href="">view more</a>
                                           </div>
                                       </article>
                                       <article>
                                           <h4>ベストこども新聞<span>/</span>生徒が書いた新聞です</h4>
                                           <figure>
                                               <img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-img01.png" alt="guide image">
                                           </figure>
                                           <div class="view-btn">
                                                <a href="">view more</a>
                                           </div>
                                           
                                       </article>
                                   </div>
                                </div>
                                <div class="guide-price">
                                    <div class="guide-price-ttl">
                                        <h2 class="eng-ttl"><span>P</span>RICE</h2>
                                        <h3 class="jp-ttl">料金</h3>
                                    </div>
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>学年</th>
                                                <th>授業時間</th>
                                                <th>週1回（月4回）</th>
                                                <th>週2回（月8回）</th>
                                                <th>週3回（月12回）</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>小学2年生以下</td>
                                                <td>40分</td>
                                                <td>$128</td>
                                                <td>$245</td>
                                                <td>$360</td>
                                            </tr>
                                            <tr>
                                                <td>小学3～6年生</td>
                                                <td>50分</td>
                                                <td>$133</td>
                                                <td>$255</td>
                                                <td>$370</td>
                                            </tr>
                                            <tr>
                                                <td>中学生</td>
                                                <td>50分</td>
                                                <td>$138</td>
                                                <td>$265</td>
                                                <td>$385</td>
                                            </tr>
                                            <tr>
                                                <td>高校生</td>
                                                <td>50分</td>
                                                <td>$150</td>
                                                <td>$285</td>
                                                <td>$410</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <p class="bottom-txt">
                                    表示料金は米ドル(USD)です。<a href="">（USドル以外の通貨はこちら）</a><br>
                                    中学生以上で生徒の受講レベルが小学生レベルの場合は小学生料金を適用します。<br>
                                    毎授業後、保護者の方にメールで授業報告をいたします。<br>
                                    授業料金は輸出扱いになるため、消費税(Sales Tax)はかかりません。 
                                    </p>
                                    <div class="price-flow d-fl">
                                        <div class="flow-inn d-fl">
                                            <span class="icon"><img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-ico01.svg" alt="icon"></span>
                                            <div class="flow-txt">
                                                <h4>入会金0円</h4>
                                                <p>入会金はありません。</p>
                                            </div>
                                        </div>
                                        <div class="flow-inn d-fl">
                                            <span class="icon"><img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-ico02.svg" alt="icon"></span>
                                            <div class="flow-txt">
                                                <h4>月謝制</h4>
                                                <p>最低契約期間はありません。<br>
                                                    月毎であれば、<br>
                                                    いつでも退会できます。
                                                </p>
                                            </div>
                                        </div>
                                        <div class="flow-inn d-fl">
                                            <span class="icon"><img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-ico03.svg" alt="icon"></span>
                                            <div class="flow-txt">
                                                <h4>兄弟割引</h4>
                                                <p>ご兄弟割引きで<br>
                                                    みなさまの授業料が<br>
                                                    <span>ずっと5％割引</span>になります。
                                                </p>
                                            </div>
                                        </div>
                                        <div class="flow-inn d-fl">
                                            <span class="icon"><img src="<?php echo get_template_directory_uri(); ?>/img/guide/guide-ico04.svg" alt="icon"></span>
                                            <div class="flow-txt">
                                                <h4>ご兄弟同時入会割引</h4>
                                                <p>お二人目の、<br>
                                                  初月<span>50ドル割引</span>に<br>
                                                    なります。
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>     
    </div>
    <?php get_template_part('common-banner');?>
	</main><!-- #main -->

<?php
get_footer();
