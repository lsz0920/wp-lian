<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>r</span>eview</h2>
                <h3 class="jp-ttl">ユーザーレビュー</h3>
            </div>
            <div class="sl-subpage-list">
                <ul>
                    <li><a href="#">模擬試験</a></li>
                    <li><a href="#">教育セミナートップ</a></li>
                    <li><a href="#">入試実績</a></li>
                    <li><a href="#">子供新聞</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </div>
        </div>
        <div class="sl-subpage-review-inn">
            <div class="breadcrumbs inner" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-review-inn-content">
                <div class="content-list">
                    <div class="content-list-item">
                    <?php if ( have_posts() ) : ?>
                        <?php
                        while ( have_posts() ) :
                            the_post();
                            get_template_part( 'template-parts/content-review', get_post_type() );

                        endwhile;

                        endif;
                        ?>
                    </div>
                    <div class="moreBtn">
                        <a href="#">more</a>
                    </div>
                    <?php echo do_shortcode('[contact-form-7 id="213" title="お客様の声"]'); ?>
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();
