<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>a</span>nalyze</h2>
                <h3 class="jp-ttl">帰国生受験を徹底分析</h3>
            </div>
            <div class="sl-subpage-list">
                <ul>
                    <li><a href="#">模擬試験</a></li>
                    <li><a href="#">教育セミナートップ</a></li>
                    <li><a href="#">入試実績</a></li>
                    <li><a href="#">子供新聞</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </div>
        </div>
        <div class="sl-subpage-thorough-analyze-inn">
            <div class="breadcrumbs inner" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-thorough-analyze-inn-content">
                <div class="sl-subpage-thorough-analyze-inn-content-ttl">
                    <div class="content-ttl">
                        <h2><span>帰国生受験を徹底分析（中学編）</span></h2>
                    </div>
                </div>
                <div class="sl-subpage-thorough-analyze-inn-content-inn">
                    <div class="thumbnail-list d-fl">
                        <div class="thumbnail-box">
                            <a href="<?php echo esc_html( home_url('/') ) ?>thorough-analysis/entry-exams/" class="d-fl">
                            <div class="thumbnail-box-img">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/analyze/img-cir-01.png" alt="img">
                                </figure>
                            </div>
                            <div class="thumbnail-box-info">
                                <h3><span>入試について</span></h3>
                                <p>一口に帰国生受験といっても千差万別。まずはどのようなものか見てみよう。</p>
                            </div>
                            </a>
                        </div>
                        <div class="thumbnail-box">
                            <a href="<?php echo esc_html( home_url('/') ) ?>thorough-analysis/private-school/" class="d-fl">
                            <div class="thumbnail-box-img">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/analyze/img-cir-02.png" alt="img">
                                </figure>
                            </div>
                            <div class="thumbnail-box-info">
                                <h3><span>私立中学って</span></h3>
                                <p>私立中学とはどんなところ？中学の先生にお話を聞きながら見てみよう。</p>
                            </div>
                            </a>
                        </div>
                        <div class="thumbnail-box">
                            <a href="<?php echo esc_html( home_url('/') ) ?>" class="d-fl">
                            <div class="thumbnail-box-img">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/analyze/img-cir-03.png" alt="img">
                                </figure>
                            </div>
                            <div class="thumbnail-box-info">
                                <h3><span>帰国生受入校</span></h3>
                                <p>全国の帰国生入稿のリストです。</p>
                            </div>
                            </a>
                        </div>
                        <div class="thumbnail-box">
                            <a href="<?php echo esc_html( home_url('/') ) ?>" class="d-fl">
                            <div class="thumbnail-box-img">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/analyze/img-cir-04.png" alt="img">
                                </figure>
                            </div>
                            <div class="thumbnail-box-info">
                                <h3><span>オンライン学校説明会</span></h3>
                                <p>海外にお住まいの皆さまに帰国生受入校の先生によるテーマ別教育セミナーをオンラインで実施致します。</p>
                            </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();
