<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>p</span>rice</h2>
                <h3 class="jp-ttl">料金</h3>
            </div>
            <div class="sl-subpage-list">
                    <ul>
                        <li><a href="#">模擬試験</a></li>
                        <li><a href="#">教育セミナートップ</a></li>
                        <li><a href="#">入試実績</a></li>
                        <li><a href="#">子供新聞</a></li>
                        <li><a href="#">Facebook</a></li>
                        <li><a href="#">Blog</a></li>
                    </ul>
            </div>
        </div>
        <div class="sl-subpage-price-inn inner">
            <div class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-price-inn-content">
                <div class="sl-subpage-price-inn-content-box box-shadow">
                    <div class="box-data">
                        <div class="box-data-ttl">
                            <h2>小学生・中学生・高校生コース</h2>
                        </div>
                        <div class="box-data-content">
                            <div class="content-hd d-fl">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/price/price-img01.png" alt="img">
                                </figure>
                                <p>しっかりと国語、<br>
                                    算数を習得したい方の為のコースです。</p>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>週1回（月4回）</th>
                                    <th>週2回（月8回）</th>
                                    <th>週3回（月12回）</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>小学2年生以下</td>
                                        <td>40分</td>
                                        <td>$125</td>
                                        <td>$240</td>
                                        <td>$355</td>
                                    </tr>
                                    <tr>
                                        <td>小学3～6年生</td>
                                        <td>50分</td>
                                        <td>$130</td>
                                        <td>$250</td>
                                        <td>$365</td>
                                    </tr>
                                    <tr>
                                        <td>中学生</td>
                                        <td>50分</td>
                                        <td>$135</td>
                                        <td>$260</td>
                                        <td>$380</td>
                                    </tr>
                                    <tr>
                                        <td>高校生</td>
                                        <td>50分</td>
                                        <td>$140</td>
                                        <td>$272</td>
                                        <td>$400</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-ft d-fl">
                                <p>表示料金は米ドル(USD)です。（<a href="#">USドル以外の通貨はこちら</a>） <br>
                                    中学生以上で生徒の受講レベルが小学生レベルの場合は小学生料金を適用します。<br>
                                    毎授業後、保護者の方にメールで授業報告をいたします。<br>
                                    授業料金は輸出扱いになるため、消費税(Sales Tax)はかかりません。</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-price-inn-content-box box-shadow">
                    <div class="box-data">
                        <div class="box-data-ttl">
                            <h2>受験対策コース</h2>
                        </div>
                        <div class="box-data-content">
                            <div class="content-hd d-fl">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/price/price-img02.png" alt="img">
                                </figure>
                                <p>私立中学校の帰国生入試、<br>
                                    高校の帰国生入試を目指す方のコースです。 <br>
                                    現在お使いの教材があれば、<br>
                                    持ち込み教材としてご使用いただくことも可能です。</p>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>週1回（月4回）</th>
                                    <th>週2回（月8回）</th>
                                    <th>週3回（月12回）</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>中学受験</td>
                                        <td>50分</td>
                                        <td>$135</td>
                                        <td>$260</td>
                                        <td>$375</td>
                                    </tr>
                                    <tr>
                                        <td>高校受験</td>
                                        <td>50分</td>
                                        <td>$140</td>
                                        <td>$270</td>
                                        <td>$390</td>
                                    </tr>
                                    <tr>
                                        <td>大学受験</td>
                                        <td>50分</td>
                                        <td>$150</td>
                                        <td>$282</td>
                                        <td>$410</td>
                                    </tr>
                                    <tr>
                                        <td>中/高/大学受験</td>
                                        <td>90分</td>
                                        <td>$225</td>
                                        <td>$420</td>
                                        <td>$605</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-ft d-fl">
                                <p>表示料金は米ドル(USD)です。（<a href="#">USドル以外の通貨はこちら</a>）<br>
                                    毎授業後、保護者の方にメールで授業報告をいたします。<br>
                                    90分間授業は途中に5分程度の休憩を含みます。<br>
                                    持ち込み教材の場合、別途講師用の教材実費がかかります。<br>
                                    授業料金は輸出扱いになるため、消費税(Sales Tax)はかかりません。</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-price-inn-content-box box-shadow">
                    <div class="box-data">
                        <div class="box-data-ttl">
                            <h2>作文指導</h2>
                        </div>
                        <div class="box-data-content">
                            <div class="content-hd d-fl">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/price/price-img03.png" alt="img">
                                </figure>
                                <p>私立中学校の帰国生入試、<br>
                                    高校の帰国生入試を目指す方のコースです。 <br>
                                    現在お使いの教材があれば、<br>
                                    持ち込み教材としてご使用いただくことも可能です。</p>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>月4回</th>
                                    <th>月4回 + 添削2回</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>作文指導</td>
                                        <td>50分</td>
                                        <td>$130</td>
                                        <td>$170</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-ft d-fl">
                                <p>表示料金は米ドル(USD)です。<br>
                                    毎授業後、保護者の方にメールで授業報告をいたします。<br>
                                    授業料金は輸出扱いになるため、消費税(Sales Tax)はかかりません。<br>
                                    作文指導コースは兄弟割引対象外です。
                                    </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-price-inn-content-box box-shadow">
                    <div class="box-data">
                        <div class="box-data-ttl">
                            <h2>日本語が苦手な方</h2>
                        </div>
                        <div class="box-data-content">
                            <div class="content-hd d-fl">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/price/price-img04.png" alt="img">
                                </figure>
                                <p>講師は、全て日本語教師のライセンスを持っているか、<br>
                                    420時間以上の日本語教師のプログラムを <br>
                                    持っている方を講師としています。<br>
                                    ひらがな、カタカナから、日本語の文型をステップｂｙステップで <br>
                                    習得していきましょう。</p>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>週1回（月4回）</th>
                                    <th>週2回（月8回）</th>
                                    <th>週3回（月12回）</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>小学2年生以下</td>
                                        <td>40分</td>
                                        <td>$125</td>
                                        <td>$240</td>
                                        <td>$355</td>
                                    </tr>
                                    <tr>
                                        <td>小学3年生以上</td>
                                        <td>50分</td>
                                        <td>$130</td>
                                        <td>$250</td>
                                        <td>$365</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-ft d-fl">
                                <p>表示料金は米ドル(USD)です。（<a href="#">USドル以外の通貨はこちら</a>）<br>
                                    毎授業後、保護者の方にメールで授業報告をいたします。<br>
                                    授業料金は輸出扱いになるため、消費税(Sales Tax)はかかりません。
                                    </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-price-inn-content-box box-shadow">
                    <div class="box-data">
                        <div class="box-data-ttl">
                            <h2>幼児コース</h2>
                        </div>
                        <div class="box-data-content">
                            <div class="content-hd d-fl img-hd">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/price/price-img05.png" alt="img">
                                </figure>
                                <p>ご家庭での言語環境も含めて、講師がアドバイスしていきながら <br>
                                    ご家庭と一緒になって進めていくバイリンガルの為の <br>
                                    教育プログラムです。 <br>
                                    お子様と一緒に楽しく勉強していき、<br>
                                    日本語が好きになってもらう授業を心がけています。</p>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>週1回（月4回）</th>
                                    <th>週2回（月8回）</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>6歳以下</td>
                                        <td>40分</td>
                                        <td>$125</td>
                                        <td>$240</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-ft d-fl">
                                <p>表示料金は米ドル(USD)です。（<a href="#">USドル以外の通貨はこちら</a>）<br>
                                    毎授業後、保護者の方にメールで授業報告をいたします。<br>
                                    授業料金は輸出扱いになるため、消費税(Sales Tax)はかかりません。
                                    </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-price-inn-content-box box-shadow">
                    <div class="box-data">
                        <div class="box-data-ttl">
                            <h2>帰国子女英語コース</h2>
                        </div>
                        <div class="box-data-content">
                            <div class="content-hd d-fl img-hd">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/price/price-img06.png" alt="img">
                                </figure>
                                <p>海外からの帰国後、お子様が身につけた英語能力をキープ、<br>
                                    向上させるためプログラムです。<br>
                                    講師はアメリカ人やカナダ人などのネイティブスピーカーです。</p>
                            </div>
                            <table>
                                <thead>
                                    <th>コース</th>
                                    <th>授業時間</th>
                                    <th>週1回（月4回）</th>
                                    <th>週2回（月8回）</th>
                                    <th>週3回（月12回）</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>35分間コース</td>
                                        <td>35分</td>
                                        <td class="align-right">13,000円 <br>
                                        (税込  14,300円)</td>
                                        <td class="align-right">25,000円 <br>
                                        (税込  27,500円)</td>
                                        <td class="align-right">37,000円 <br>
                                        (税込  40,700円)</td>
                                    </tr>
                                    <tr>
                                        <td>45分間コース</td>
                                        <td>45分</td>
                                        <td class="align-right">13,800円 <br>
                                        (税込  15,180円)</td>
                                        <td class="align-right">26,500円 <br>
                                        (税込  29,150円)</td>
                                        <td class="align-right">38,700円 <br>
                                        (税込  42,570円)</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-ft d-fl">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();
