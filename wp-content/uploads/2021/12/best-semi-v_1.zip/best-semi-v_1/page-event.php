<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>e</span>vent</h2>
                <h3 class="jp-ttl">イベント</h3>
            </div>
            <div class="sl-subpage-list">
                <ul>
                    <li><a href="#">模擬試験</a></li>
                    <li><a href="#">教育セミナートップ</a></li>
                    <li><a href="#">入試実績</a></li>
                    <li><a href="#">子供新聞</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </div>
        </div>
        <div class="sl-subpage-event-inn">
            <div class="breadcrumbs inner" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-event-inn-content">
                <div class="sl-subpage-event-inn-content-box">
                    <div class="box-ttl">
                        <h2>夏休み企画</h2>
                    </div>
                    <div class="box-data">
                        <div class="box-data-mv">
                            <figure>
                                <img src="<?php echo get_template_directory_uri(); ?>/img/event/event-mv.jpg" alt="">
                            </figure>
                            <span class="ttl">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/event/title.svg" alt="">
                                </figure>
                            </span>
                            <span class="badge">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/event/badge.svg" alt="">
                                </figure>
                            </span>
                        </div>
                        <div class="box-data-content">
                            <div class="box-data-content-info">
                                <p>
                                    ネイティブの先生と話し放題、聞き放題の自習室です。<br>
                                    宿題のわからないところを質問したり、英語のフリートークをお楽しみください。
                                </p>
                            </div>
                            <div class="box-data-content-list d-fl">
                                <div class="content-img">
                                    <figure>
                                        <img src="<?php echo get_template_directory_uri(); ?>/img/event/img01.png" alt="">
                                    </figure>
                                </div>
                                <div class="content-table">
                                    <table>
                                        <tr>
                                            <td>8月16日（月）</td>
                                            <td>7:30～9：00pm</td>
                                        </tr>
                                        <tr>
                                            <td>8月23日（月）</td>
                                            <td>7:30～9：00pm</td>
                                        </tr>
                                        <tr>
                                            <td>8月30日（月）</td>
                                            <td>7:30～9：00pm</td>
                                        </tr>
                                    </table>
                                    <span><p>日本時間</p></span>
                                </div>
                            </div>
                            <div class="box-data-content-info">
                                <p>
                                    どなた様でも無料でご参加できます。参加方法は、下の「参加の仕方」をご確認ください。
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-event-inn-content-box">
                    <div class="box-ttl">
                        <h2>参加の仕方</h2>
                    </div>
                    <div class="box-data">
                        <div class="box-data-content">
                            <table>
                                <tr>
                                    <th><span>ログイン方法</span></th>
                                    <td>開始時刻になりましたら、下の「ログイン」を押して【 Zoom5 】へ入室してください。
                                        入室ができたら「コンピュータでオーディオに参加」を押してください。
                                    </td>
                                </tr>
                                <tr>
                                    <th><span>会議室の説明</span></th>
                                    <td>
                                    <figure>
                                            <img src="<?php echo get_template_directory_uri(); ?>/img/event/img02.png" alt="">
                                        </figure>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();
