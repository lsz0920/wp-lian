<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>e</span>nterprise</h2>
                <h3 class="jp-ttl">法人のみなさまへ</h3>
            </div>
            <div class="sl-subpage-list">
                    <ul>
                        <li><a href="#">模擬試験</a></li>
                        <li><a href="#">教育セミナートップ</a></li>
                        <li><a href="#">入試実績</a></li>
                        <li><a href="#">子供新聞</a></li>
                        <li><a href="#">Facebook</a></li>
                        <li><a href="#">Blog</a></li>
                    </ul>
            </div>
        </div>
        <div class="sl-subpage-enterprise-inn">
           <div class="breadcrumbs inner" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-enterprise-inn-content">
                <div class="sl-subpage-enterprise-inn-content-ttl">
                    <div class="content-ttl">
                        <h2>ベストゼミナール法人会員のご案内</h2>
                    </div>
                </div>
                <div class="sl-subpage-enterprise-inn-content-info">
                    <p>
                        海外でご活躍されております、御社従業員のご家族に、ご自宅で受講可能なオンライン個別指導塾サービスを御社のコスト負担無く、御社現地法人の従業員のご家族に法人用の特別価格、条件にてご提案させて頂きます。
                        <br><br>
                        <span>御社の登録料は一切かかりません。</span>
                        <br><br>
                    </p>
                    <ul>
                        <li>・海外駐在終了後、お子様に帰国生受験を考えていらっしゃる方。</li>
                        <li>・海外駐在中、国語教育がおろそかになることにより、帰国後のお子様の学力に不安をお持ちの方。</li>
                        <li>・お近くに日本語学校や日本語補習校が無く、通学に時間がかかりすぎる方。</li>
                        <li>・従業員のご子弟で、日本語教育を検討されている方。</li>
                    </ul>
                </div>
                <div class="sl-subpage-enterprise-inn-content-box">
                    <div class="box-data">
                        <div class="box-data-ttl">
                            <h2>特典① 通常の授業料に対し8%割引</h2>
                        </div>
                        <div class="box-data-content">
                            <div class="content-hd d-fl">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/enterprise/img01.png" alt="img">
                                </figure>
                                <p>
                                    御社と法人登録をして頂くことで、<br>
                                    御社従業員のご家族に対し、<br>
                                    マンツーマンの授業を下記の特別料金でのご提供をさせて頂きます。
                                </p>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>週1回（月4回）</th>
                                    <th>週2回（月8回）</th>
                                    <th>週3回（月12回）</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>小学2年生以下</td>
                                        <td>40分</td>
                                        <td>
                                            <span class="last">$125</span>
                                            <span class="new">$115</span>
                                        </td>
                                        <td>
                                            <span class="last">$240</span>
                                            <span class="new">$220</span>
                                        </td>
                                        <td>
                                            <span class="last">$355</span>
                                            <span class="new">$326</span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>小学3～6年生</td>
                                        <td>50分</td>
                                        <td>
                                            <span class="last">$130</span>
                                            <span class="new">$119</span>
                                        </td>
                                        <td>
                                            <span class="last">$250</span>
                                            <span class="new">$230</span>
                                        </td>
                                        <td>
                                            <span class="last">$365</span>
                                            <span class="new">$335</span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>中学生</td>
                                        <td>50分</td>
                                        <td>
                                            <span class="last">$135</span>
                                            <span class="new">$124</span>
                                        </td>
                                        <td>
                                            <span class="last">$260</span>
                                            <span class="new">$239</span>
                                        </td>
                                        <td>
                                            <span class="last">$380</span>
                                            <span class="new">$349</span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>高校生</td>
                                        <td>50分</td>
                                        <td>
                                            <span class="last">$142</span>
                                            <span class="new">$130</span>
                                        </td>
                                        <td>
                                            <span class="last">$272</span>
                                            <span class="new">$250</span>
                                        </td>
                                        <td>
                                            <span class="last">$400</span>
                                            <span class="new">$368</span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>中/高 受験対策	</td>
                                        <td>50分</td>
                                        <td>
                                            <span class="last">$135</span>
                                            <span class="new">$24</span>
                                        </td>
                                        <td>
                                            <span class="last">$260</span>
                                            <span class="new">$239</span>
                                        </td>
                                        <td>
                                            <span class="last">$375</span>
                                            <span class="new">$345</span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>中/高 受験対策	</td>
                                        <td>90分</td>
                                        <td>
                                            <span class="last">$225</span>
                                            <span class="new">$207</span>
                                        </td>
                                        <td>
                                            <span class="last">$420</span>
                                            <span class="new">$386</span>
                                        </td>
                                        <td>
                                            <span class="last">$605</span>
                                            <span class="new">$556</span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>月4回 + 添削2回</th>
                                    <th>月4回 + 添削2回</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>作文指導</td>
                                        <td>50分</td>
                                        <td>
                                            <span class="last">$225</span>
                                            <span class="new">$119</span>
                                        </td>
                                        <td>
                                            <span class="last">$420</span>
                                            <span class="new">$156</span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-ft d-fl">
                                <ul>
                                    <li>*表示は月額料金です。</li>
                                    <li>*兄弟割引との併用はできません。</li>
                                    <li>*教材の割引には適用されません。</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-enterprise-inn-content-box">
                    <div class="box-data">
                        <div class="box-data-ttl">
                            <h2>特典② 無料体験レッスン</h2>
                        </div>
                        <div class="box-data-content">
                            <div class="content-hd d-fl">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/enterprise/img02.png" alt="img">
                                </figure>
                                <p>
                                    1ヵ月間（4回）体験授業を無料でご提供させて頂き、<br>
                                    利用者には納得して頂いた上で、料金を頂いています。<br>
                                    なお、無料体験期間終了後、入会の義務はありませので安心してお試し下さい。
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-enterprise-inn-content-box">
                    <div class="box-data">
                        <div class="box-data-ttl">
                            <h2>法人会員のお申込みについて</h2>
                        </div>
                        <div class="box-data-content">
                            <table class="sub-tb">
                                <thead>
                                    <th>対象地域</th>
                                    <th>北米・オーストラリア・ヨーロッパ・アジア地区</th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>法人登録料</td>
                                        <td>
                                            <span>無料</span>
                                            登録料は、一切かかりません。御社の福利厚生として、
                                            当社カタログと一緒に社員の方に御紹介下さい。
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="mail-btn">
                                <a href="mailto:info@best-semi.com">E-mail:info@best-semi.com</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();
