<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>B</span>LOG</h2>
                <h3 class="jp-ttl">ブログ</h3>
            </div>
            <div class="sl-subpage-list">
                <ul>
                    <li><a href="#">模擬試験</a></li>
                    <li><a href="#">教育セミナートップ</a></li>
                    <li><a href="#">入試実績</a></li>
                    <li><a href="#">子供新聞</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </div>
        </div>
        <div class="sl-subpage-blog-inn inner">
            <div class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-blog-inn-content">
                <div class="sl-subpage-blog-inn-content-list">
                <?php 
                        $category_terms = get_terms([
                            'taxonomy' => 'blog_category',
                            'hide_empty' => false,
                            'order'   => 'DESC'
                        ]);
		 	        ?>
                    <div class="list-item">
                        <ul class="d-fl">
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>blog">記事一覧</a></li>
                            <?php foreach($category_terms as $category_term): ?>
                            <li><a href="<?php echo get_term_link($category_term); ?>"><?php echo $category_term->name; ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
                <div class="sl-subpage-blog-inn-content-data">
                    <div class="blog-ttl hd-underline">
                        <h2>記事一覧</h2>
                    </div>
                    <div class="data-item">
                    <?php if ( have_posts() ) : ?>

                    <?php

                    while ( have_posts() ) :
                        the_post();
                        get_template_part( 'template-parts/content-blog', get_post_type() );

                    endwhile;

                    endif;
                    ?>
                    </div>
                </div>
                <div class="moreBtn">
                    <a href="#">more</a>
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main><!-- #main -->

<?php
get_footer();
