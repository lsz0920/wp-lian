<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>p</span>rivacy policy</h2>
                <h3 class="jp-ttl">プライバシーポリシー</h3>
            </div>
            <div class="sl-subpage-list">
                    <ul>
                        <li><a href="#">模擬試験</a></li>
                        <li><a href="#">教育セミナートップ</a></li>
                        <li><a href="#">入試実績</a></li>
                        <li><a href="#">子供新聞</a></li>
                        <li><a href="#">Facebook</a></li>
                        <li><a href="#">Blog</a></li>
                    </ul>
            </div>
        </div>
        <div class="sl-subpage-pp-inn inner">
            <div class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-pp-inn-content">
                <div class="sl-subpage-pp-inn-content-ttl">
                    <p>
                        株式会社ファイブスタート（以下、「当社」）は、個人情報保護の重要性を強く認識し、個人情報の保護に関しては「個人情報
                        保護法」に従い取り扱います。また、利用者に安心してご利用頂く為に、「個人情報保護方針」を制定し、役員ならびに社員
                        はこの方針に従い、この方針の遵守の為の教育、指導、管理を行います。
                    </p>
                </div>
                <div class="sl-subpage-pp-inn-content-box box-shadow">
                    <div class="box-data">
                        <h3>1．個人情報の収集</h3>
                        <p>当社のサービスの提供及び、授業の向上等、事業活動に必要な範囲内でのみ、個人情報を収集致します。</p>
                        <h3>2．個人情報の管理</h3>
                        <p>当社は「個人情報保護方針」を制定し、役員ならびに社員はこの方針に従い、この方針の遵守の為の必要な指導、管理を行います。</p>
                        <h3>3．個人情報の利用</h3>
                        <p>当社は各種サービスの提供、教材の郵送、及びメールや電話による連絡手段以外の目的では個人情報を利用致しません。</p>
                        <h3>4．個人情報の開示</h3>
                        <p>当社は下記のいずれかに該当する場合を除いて、許可なく当社以外の第3者に個人情報を開示することはありません。</p>
                            <ul>
                                <li>法令に基づく場合</li>
                                <li>人の生命、身体または財産の保護の為に必要がある場合で、ご本人の同意を得ることが困難であるとき</li>
                                <li>公衆衛生の向上または児童の健全な育成の推進の為に特に必要がある場合で、ご本人の同意を得ること が困難であるとき</li>
                                <li>国の機関もしくは地方公共団体、またはその委託を受けた者が法令の定める事務を遂行することに対し て協力する必要がある場合であって、ご本人の同意を得ることにより当該事務の遂行に支障を及ぼす　  恐れがあるとき</li>
                                <li>決済等の為金融機関等に個人情報を開示する必要がある場合</li>
                            </ul>
                        <h3>5．個人情報の削除</h3>
                        <p>当社はお客様からの依頼に基づき、個人情報の削除を希望される場合、速やかに対処致します。</p>
                        <h3>お問い合わせ</h3>
                        <p>個人情報の紹介・修正・削除等ご希望の場合は、下記へご連絡下さい。
                            ご本人様確認を行った上で、適切に対処致します。
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();
