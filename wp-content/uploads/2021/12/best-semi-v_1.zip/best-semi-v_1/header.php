<?php
/**
 * @package v_1.0.1
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

    <!-- font links -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700;800;900&family=Noto+Sans+JP:wght@300;400;500;700;900&display=swap" rel="stylesheet">

	<!-- slick css link -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/style.min.css?v=1.2.0.<?=rand()?>">

	<?php wp_head(); ?>
	<script>
    (function(d) {
        var config = {
        kitId: 'xwm2zah',
        scriptTimeout: 3000,
        async: true
        },
        h=d.documentElement,t=setTimeout(function(){h.className=h.className.replace(/\bwf-loading\b/g,"")+" wf-inactive";},config.scriptTimeout),tk=d.createElement("script"),f=false,s=d.getElementsByTagName("script")[0],a;h.className+=" wf-loading";tk.src='https://use.typekit.net/'+config.kitId+'.js';tk.async=true;tk.onload=tk.onreadystatechange=function(){a=this.readyState;if(f||a&&a!="complete"&&a!="loaded")return;f=true;clearTimeout(t);try{Typekit.load(config)}catch(e){}};s.parentNode.insertBefore(tk,s)
    })(document);
    </script>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site l">
<header id="masthead" class="site-header l-hd">
            <div class="l-hd-inn d-fl">
                <div class="l-hd-inn-logo">
                    <h1>
                        <a href="<?php echo esc_html( home_url('/') ) ?>">
                            <img src="<?php echo get_template_directory_uri(); ?>/img/common/logo.svg" alt="logo">
                        </a>
                    </h1>
                </div>
                <div class="l-hd-inn-R">
                    <div class="l-hd-inn-R-01 d-fl">
                        <div class="menu-bar">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div class="about">
                            <a href="<?php echo esc_html( home_url('/') ) ?>" rel="noreferrer"><span><img src="<?php echo get_template_directory_uri(); ?>/img/common/home-ico.png" alt="icon image" class="img"><img src="<?php echo get_template_directory_uri(); ?>/img/common/home-ico-hover.png" alt="icon image" class="img-hover"></span> 企業・団体向け</a>
                        </div>
                        <ul class="language">
                            <li><a href="" rel="noreferrer" class="active">JP</a></li>
                            <li><a href="" rel="noreferrer">EN</a></li>
                        </ul>
                    </div>
                    <nav>
                        <div class="close-menu">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <ul class="l-hd-inn-nav">
                            <li class="show-more">
                                <a rel="noreferrer">永住者向け</a>
                                <div class="dropdown">
                                    <ul class="d-fl">
                                        <li><a href="<?php echo esc_html( home_url('/') ) ?>guide/#read-write" rel="noreferrer">読み書きをしっかり習得</a></li>
                                        <li><a href="<?php echo esc_html( home_url('/') ) ?>guide/#notgood-jp" rel="noreferrer">日本語が苦手なお子様</a></li>
                                        <li><a href="<?php echo esc_html( home_url('/') ) ?>guide/#young-child" rel="noreferrer">6歳未満のお子様</a></li>
                                        <li><a href="<?php echo esc_html( home_url('/') ) ?>guide/#jlpt" rel="noreferrer">日本語試験対策</a></li>
                                    </ul>
                                </div>
                            </li>
                            <li class="show-more">
                                <a rel="noreferrer">駐在員のお子</a>
                                <div class="dropdown">
                                    <ul class="d-fl">
                                        <li><a href="<?php echo esc_html( home_url('/') ) ?>" rel="noreferrer">教科書に沿った学習指導</a></li>
                                        <li><a href="<?php echo esc_html( home_url('/') ) ?>" rel="noreferrer">帰国生受験対策</a></li>
                                        <li><a href="<?php echo esc_html( home_url('/') ) ?>" rel="noreferrer">作文指導</a></li>
                                    </ul>
                                </div>
                            </li>
                            <li class="show-more">
                                <a rel="noreferrer">受験対策</a>
                                <div class="dropdown">
                                    <ul class="d-fl">
                                        <li><a href="<?php echo esc_html( home_url('/') ) ?>" rel="noreferrer">帰国生受験対策</a></li>
                                        <li><a href="<?php echo esc_html( home_url('/') ) ?>" rel="noreferrer">作文指導</a></li>
                                    </ul>
                                </div>
                            </li>
                            <li>
                                <a href="<?php echo esc_html( home_url('/') ) ?>" rel="noreferrer">帰国子女の英語</a>
                            </li>
                            <li>
                                <a href="<?php echo esc_html( home_url('/') ) ?>price/" rel="noreferrer">料金表</a>
                            </li>
                            <li class="sp">
                                <a href="<?php echo esc_html( home_url('/') ) ?>" rel="noreferrer">MEMBER</a>
                            </li>
                            <div class="member sp">
                                <a href="" rel="noreferrer"><span><img src="<?php echo get_template_directory_uri(); ?>/img/common/home-ico-sp.png" alt="icon image"></span> 企業・団体向け</a>
                            </div>
                        </ul>
                    </nav>

                </div>
                <div class="l-hd-inn-member">
                    <a href="<?php echo esc_html( home_url('/') ) ?>" rel="noreferrer">MEMBER</a>
                </div>

            </div>
        </header>
	<div id="content" class="site-content">
		<div id="primary" class="content-area">
