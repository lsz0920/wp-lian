<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>B</span>LOG</h2>
                <h3 class="jp-ttl">ブログ</h3>
            </div>
            <div class="sl-subpage-list">
                    <ul>
                        <li><a href="#">模擬試験</a></li>
                        <li><a href="#">教育セミナートップ</a></li>
                        <li><a href="#">入試実績</a></li>
                        <li><a href="#">子供新聞</a></li>
                        <li><a href="#">Facebook</a></li>
                        <li><a href="#">Blog</a></li>
                    </ul>
            </div>
        </div>
        <div class="sl-subpage-blog-inn inner">
            <div class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-blog-inn-content">
                <div class="sl-subpage-blog-inn-content-box box-shadow">
                    <div class="box-data">
                        <span class="date"><?php the_time('Y.m.d'); ?></span>
                        <h3><?php the_title(); ?></h3>
                        <?php the_content(); ?>
                    </div>
                </div>
                <div class="moreBtn list-btn">
                    <a href="<?php echo esc_html( home_url('/') ) ?>blog">一覧へ戻る</a>
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main><!-- #main -->

<?php
get_footer();
