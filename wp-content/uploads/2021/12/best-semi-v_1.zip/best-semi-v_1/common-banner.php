<div id="banner" class="l-contactbnr">
    <div class="l-contactbnr-inn">
        <h2><span>無料体験レッスン受付中！</span></h2>
        <p>ベストゼミナールでは、<br class="sp">安心して受講していただくために、<br class="pc" />実際の授業を<br
                class="sp"><strong>1ヶ月間無料</strong>で体験していただけます。</p>
        <div class="banner-btn d-fl">
            <div class="banner-btn-l">
                <a href="<?php echo esc_html( home_url('/') ) ?>free-trial/" rel="alternate">1ヶ月無料体験レッスン</a>
            </div>
            <div class="banner-btn-r">
                <a href="<?php echo esc_html( home_url('/') ) ?>document-request/" rel="alternate"><span>
                    <img src="<?php echo get_template_directory_uri(); ?>/img/common/doc-icon.png" alt="" class="doc-icon"><img src="<?php echo get_template_directory_uri(); ?>/img/common/doc-icon-hover.png" alt="" class="doc-icon-hover"></span>資料請求はこちら</a>
            </div>
        </div>
    </div>
</div>