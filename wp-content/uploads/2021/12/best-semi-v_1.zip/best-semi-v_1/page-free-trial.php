<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>F</span>REE TRIAL</h2>
                <h3 class="jp-ttl">無料体験レッスン申し込み</h3>
            </div>
            <div class="sl-subpage-list">
                <ul>
                    <li><a href="#">模擬試験</a></li>
                    <li><a href="#">教育セミナートップ</a></li>
                    <li><a href="#">入試実績</a></li>
                    <li><a href="#">子供新聞</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </div>
        </div>
        <div class="sl-subpage-contact">
            <div class="breadcrumbs inner" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-contact-inn inner">
                <?php echo do_shortcode('[contact-form-7 id="226" title="無料体験レッスン申し込み"]'); ?>

                <div class="trial-content">
                <div class="trial-content-box box-shadow">
                    <div class="box-ttl">
                        <h2>授業開始時間</h2>
                    </div>
                    <div class="box-data">
                        <div class="box-data-info">
                            <p>北米の方：日曜日～金曜日</p>
                        </div>
                        <table>
                            <thead>
                                <th>ハワイ</th>
                                <th>西海岸</th>
                                <th>Mountain Time</th>
                                <th>Central Time</th>
                                <th>東海岸</th>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>午後2:30</td>
                                    <td>午後4:30</td>
                                    <td>午後5:30</td>
                                    <td>午後6:30</td>
                                    <td>午後7:30</td>
                                </tr>
                                <tr>
                                    <td>午後3:30</td>
                                    <td>午後5:30</td>
                                    <td>午後6:30</td>
                                    <td>午後7:30</td>
                                    <td>午後8:30</td>
                                </tr>
                                <tr>
                                    <td>午後4:30</td>
                                    <td>午後6:30</td>
                                    <td>午後7:30</td>
                                    <td>午後8:30</td>
                                    <td>午後9:30</td>
                                </tr>
                                <tr>
                                    <td>午後5:30</td>
                                    <td>午後7:30</td>
                                    <td>午後8:30</td>
                                    <td>午後9:30</td>
                                    <td>午後10:30</td>
                                </tr>
                                <tr>
                                    <td>午後6:30</td>
                                    <td>午後8:30</td>
                                    <td>午後9:30</td>
                                    <td>午後10:30</td>
                                    <td>午後11:30</td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="box-data-info">
                            <p>アジア・太平洋の方：月曜日～金曜日</p>
                        </div>
                        <table>
                            <tbody>
                                <tr>
                                    <td>日本時間</td>
                                    <td>午前9:30～午後9:00（土曜日は、午後6:00まで）</td>
                                </tr>
                                <tr>
                                    <td>オーストラリア</td>
                                    <td>午前10:30～午後8:00（土曜日は、午後5:00まで）</td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="box-data-ft-info">
                            <p>それ以外の時間帯をご希望の方はスタッフにご相談ください。</p>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();
