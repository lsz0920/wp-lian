<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>p</span>rice</h2>
                <h3 class="jp-ttl">各通貨での料金</h3>
            </div>
            <div class="sl-subpage-list">
                    <ul>
                        <li><a href="#">模擬試験</a></li>
                        <li><a href="#">教育セミナートップ</a></li>
                        <li><a href="#">入試実績</a></li>
                        <li><a href="#">子供新聞</a></li>
                        <li><a href="#">Facebook</a></li>
                        <li><a href="#">Blog</a></li>
                    </ul>
            </div>
        </div>
        <div class="sl-subpage-fees-inn inner">
            <div class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-fees-inn-content">
                <div class="sl-subpage-fees-inn-content-box box-shadow">
                    <div class="box-data">
                        <div class="box-data-ttl">
                            <h2>オーストラリアドル建て</h2>
                        </div>
                        <div class="box-data-content">
                            <div class="content-hd">
                                <h2><span>小学生・中学生・高校生コース</span></h2>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>週1回（月4回）</th>
                                    <th>週2回（月8回）</th>
                                    <th>週3回（月12回）</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>小学2年生以下</td>
                                        <td>40分</td>
                                        <td>144豪ドル</td>
                                        <td>276豪ドル</td>
                                        <td>408豪ドル</td>
                                    </tr>
                                    <tr>
                                        <td>小学3～6年生</td>
                                        <td>50分</td>
                                        <td>150豪ドル</td>
                                        <td>288豪ドル</td>
                                        <td>420豪ドル</td>
                                    </tr>
                                    <tr>
                                        <td>中学生</td>
                                        <td>50分</td>
                                        <td>155豪ドル</td>
                                        <td>299豪ドル</td>
                                        <td>437豪ドル</td>
                                    </tr>
                                    <tr>
                                        <td>高校生</td>
                                        <td>50分</td>
                                        <td>163豪ドル</td>
                                        <td>313豪ドル</td>
                                        <td>460豪ドル</td>
                                    </tr>
                                    <tr>
                                        <td>90分間授業</td>
                                        <td>90分</td>
                                        <td>257豪ドル</td>
                                        <td>483豪ドル</td>
                                        <td>696豪ドル</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-hd">
                                <h2><span>作文指導</span></h2>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>月4回</th>
                                    <th>月4回 + 添削2回</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>作文指導</td>
                                        <td>50分</td>
                                        <td>150豪ドル</td>
                                        <td>187豪ドル</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-hd">
                                <h2><span>受験対策コース</span></h2>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>週1回（月4回）</th>
                                    <th>週2回（月8回）</th>
                                    <th>週3回（月12回）</th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>小学生（受験指導）</td>
                                        <td>50分</td>
                                        <td>156豪ドル</td>
                                        <td>300豪ドル</td>
                                        <td>442豪ドル</td>
                                    </tr>
                                    <tr>
                                        <td>中学生（受験指導）</td>
                                        <td>50分</td>
                                        <td>160豪ドル</td>
                                        <td>312豪ドル</td>
                                        <td>450豪ドル</td>
                                    </tr>
                                    <tr>
                                        <td>高学生（受験指導）</td>
                                        <td>50分</td>
                                        <td>173豪ドル</td>
                                        <td>326豪ドル</td>
                                        <td>473豪ドル</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-ft d-fl">
                                <p>90分間授業は途中に5分程度の休憩を含みます。<br>
                                    毎授業後、保護者の方にメールで授業報告をいたします。<br>
                                    授業料金は輸出扱いになるため、消費税(Sales Tax)はかかりません。
                                    </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-fees-inn-content-box box-shadow">
                    <div class="box-data">
                        <div class="box-data-ttl">
                            <h2>オーストラリアドル建て</h2>
                        </div>
                        <div class="box-data-content">
                            <div class="content-hd">
                                <h2><span>小学生・中学生・高校生コース</span></h2>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>週1回（月4回）</th>
                                    <th>週2回（月8回）</th>
                                    <th>週3回（月12回）</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>小学2年生以下</td>
                                        <td>40分</td>
                                        <td>144豪ドル</td>
                                        <td>276豪ドル</td>
                                        <td>408豪ドル</td>
                                    </tr>
                                    <tr>
                                        <td>小学3～6年生</td>
                                        <td>50分</td>
                                        <td>150豪ドル</td>
                                        <td>288豪ドル</td>
                                        <td>420豪ドル</td>
                                    </tr>
                                    <tr>
                                        <td>中学生</td>
                                        <td>50分</td>
                                        <td>155豪ドル</td>
                                        <td>299豪ドル</td>
                                        <td>437豪ドル</td>
                                    </tr>
                                    <tr>
                                        <td>高校生</td>
                                        <td>50分</td>
                                        <td>163豪ドル</td>
                                        <td>313豪ドル</td>
                                        <td>460豪ドル</td>
                                    </tr>
                                    <tr>
                                        <td>90分間授業</td>
                                        <td>90分</td>
                                        <td>257豪ドル</td>
                                        <td>483豪ドル</td>
                                        <td>696豪ドル</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-hd">
                                <h2><span>作文指導</span></h2>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>月4回</th>
                                    <th>月4回 + 添削2回</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>作文指導</td>
                                        <td>50分</td>
                                        <td>150豪ドル</td>
                                        <td>187豪ドル</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-hd">
                                <h2><span>受験対策コース</span></h2>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>週1回（月4回）</th>
                                    <th>週2回（月8回）</th>
                                    <th>週3回（月12回）</th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>小学生（受験指導）</td>
                                        <td>50分</td>
                                        <td>156豪ドル</td>
                                        <td>300豪ドル</td>
                                        <td>442豪ドル</td>
                                    </tr>
                                    <tr>
                                        <td>中学生（受験指導）</td>
                                        <td>50分</td>
                                        <td>160豪ドル</td>
                                        <td>312豪ドル</td>
                                        <td>450豪ドル</td>
                                    </tr>
                                    <tr>
                                        <td>高学生（受験指導）</td>
                                        <td>50分</td>
                                        <td>173豪ドル</td>
                                        <td>326豪ドル</td>
                                        <td>473豪ドル</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-ft d-fl">
                                <p>90分間授業は途中に5分程度の休憩を含みます。<br>
                                    毎授業後、保護者の方にメールで授業報告をいたします。<br>
                                    授業料金は輸出扱いになるため、消費税(Sales Tax)はかかりません。
                                    </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-fees-inn-content-box box-shadow">
                    <div class="box-data">
                        <div class="box-data-ttl">
                            <h2>オーストラリアドル建て</h2>
                        </div>
                        <div class="box-data-content">
                            <div class="content-hd">
                                <h2><span>小学生・中学生・高校生コース</span></h2>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>週1回（月4回）</th>
                                    <th>週2回（月8回）</th>
                                    <th>週3回（月12回）</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>小学2年生以下</td>
                                        <td>40分</td>
                                        <td>¥13,300</td>
                                        <td>¥25,400</td>
                                        <td>¥37,600</td>
                                    </tr>
                                    <tr>
                                        <td>小学3～6年生</td>
                                        <td>50分</td>
                                        <td>¥13,800</td>
                                        <td>¥26,500</td>
                                        <td>¥38,700</td>
                                    </tr>
                                    <tr>
                                        <td>中学生</td>
                                        <td>50分</td>
                                        <td>¥14,300</td>
                                        <td>¥27,600</td>
                                        <td>¥40,300</td>
                                    </tr>
                                    <tr>
                                        <td>高校生</td>
                                        <td>50分</td>
                                        <td>¥15,100</td>
                                        <td>¥28,800</td>
                                        <td>¥42,400</td>
                                    </tr>
                                    <tr>
                                        <td>90分間授業</td>
                                        <td>90分</td>
                                        <td>¥23,900</td>
                                        <td>¥44,500</td>
                                        <td>¥64,100</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-hd">
                                <h2><span>作文指導</span></h2>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>月4回</th>
                                    <th>月4回 + 添削2回</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>作文指導</td>
                                        <td>50分</td>
                                        <td>¥13,800</td>
                                        <td>¥18,000</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-hd">
                                <h2><span>受験対策コース</span></h2>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>週1回（月4回）</th>
                                    <th>週2回（月8回）</th>
                                    <th>週3回（月12回）</th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>小学生（受験指導）</td>
                                        <td>50分</td>
                                        <td>¥14,300</td>
                                        <td>¥27,600</td>
                                        <td>¥39,800</td>
                                    </tr>
                                    <tr>
                                        <td>中学生（受験指導）</td>
                                        <td>50分</td>
                                        <td>¥14,800</td>
                                        <td>¥28,700</td>
                                        <td>¥41,400</td>
                                    </tr>
                                    <tr>
                                        <td>高学生（受験指導）</td>
                                        <td>50分</td>
                                        <td>¥16,000</td>
                                        <td>¥29,900</td>
                                        <td>¥43,500</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-ft d-fl">
                                <p>90分間授業は途中に5分程度の休憩を含みます。<br>
                                    毎授業後、保護者の方にメールで授業報告をいたします。<br>
                                    授業料金は輸出扱いになるため、消費税(Sales Tax)はかかりません。
                                    </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-fees-inn-content-box box-shadow">
                    <div class="box-data">
                        <div class="box-data-ttl">
                            <h2>オーストラリアドル建て</h2>
                        </div>
                        <div class="box-data-content">
                            <div class="content-hd">
                                <h2><span>小学生・中学生・高校生コース</span></h2>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>週1回（月4回）</th>
                                    <th>週2回（月8回）</th>
                                    <th>週3回（月12回）</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>小学2年生以下</td>
                                        <td>40分</td>
                                        <td>€113</td>
                                        <td>€216</td>
                                        <td>€320</td>
                                    </tr>
                                    <tr>
                                        <td>小学3～6年生</td>
                                        <td>50分</td>
                                        <td>€117</td>
                                        <td>€225</td>
                                        <td>€329</td>
                                    </tr>
                                    <tr>
                                        <td>中学生</td>
                                        <td>50分</td>
                                        <td>€122</td>
                                        <td>€234</td>
                                        <td>€342</td>
                                    </tr>
                                    <tr>
                                        <td>高校生</td>
                                        <td>50分</td>
                                        <td>€128</td>
                                        <td>€245</td>
                                        <td>€360</td>
                                    </tr>
                                    <tr>
                                        <td>90分間授業</td>
                                        <td>90分</td>
                                        <td>€203</td>
                                        <td>€378</td>
                                        <td>€545</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-hd">
                                <h2><span>作文指導</span></h2>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>月4回</th>
                                    <th>月4回 + 添削2回</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>作文指導</td>
                                        <td>50分</td>
                                        <td>€117</td>
                                        <td>€153</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-hd">
                                <h2><span>受験対策コース</span></h2>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>週1回（月4回）</th>
                                    <th>週2回（月8回）</th>
                                    <th>週3回（月12回）</th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>小学生（受験指導）</td>
                                        <td>50分</td>
                                        <td>€121</td>
                                        <td>€233</td>
                                        <td>€335</td>
                                    </tr>
                                    <tr>
                                        <td>中学生（受験指導）</td>
                                        <td>50分</td>
                                        <td>€126</td>
                                        <td>€238</td>
                                        <td>€350</td>
                                    </tr>
                                    <tr>
                                        <td>高学生（受験指導）</td>
                                        <td>50分</td>
                                        <td>€134</td>
                                        <td>€253</td>
                                        <td>€368</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-ft d-fl">
                                <p>90分間授業は途中に5分程度の休憩を含みます。<br>
                                    毎授業後、保護者の方にメールで授業報告をいたします。<br>
                                    授業料金は輸出扱いになるため、消費税(Sales Tax)はかかりません。
                                    </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-fees-inn-content-box box-shadow">
                    <div class="box-data">
                        <div class="box-data-ttl">
                            <h2>オーストラリアドル建て</h2>
                        </div>
                        <div class="box-data-content">
                            <div class="content-hd">
                                <h2><span>小学生・中学生・高校生コース</span></h2>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>週1回（月4回）</th>
                                    <th>週2回（月8回）</th>
                                    <th>週3回（月12回）</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>小学2年生以下</td>
                                        <td>40分</td>
                                        <td>3,320 MXN</td>
                                        <td>6,360 MXN</td>
                                        <td>9,400 MXN</td>
                                    </tr>
                                    <tr>
                                        <td>小学3～6年生</td>
                                        <td>50分</td>
                                        <td>3,445 MXN</td>
                                        <td>6,630 MXN</td>
                                        <td>9,880 MXN</td>
                                    </tr>
                                    <tr>
                                        <td>中学生</td>
                                        <td>50分</td>
                                        <td>3,580 MXN</td>
                                        <td>6,890 MXN</td>
                                        <td>10,070 MXN</td>
                                    </tr>
                                    <tr>
                                        <td>高校生</td>
                                        <td>50分</td>
                                        <td>3,770 MXN</td>
                                        <td>7,200 MXN</td>
                                        <td>10,600 MXN</td>
                                    </tr>
                                    <tr>
                                        <td>90分間授業</td>
                                        <td>90分</td>
                                        <td>6,000 MXN</td>
                                        <td>11,130 MXN</td>
                                        <td>16,100 MXN</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-hd">
                                <h2><span>作文指導</span></h2>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>月4回</th>
                                    <th>月4回 + 添削2回</th>
                                </thead>
                                 <tbody>
                                    <tr>
                                        <td>作文指導</td>
                                        <td>50分</td>
                                        <td>3,450 MXN</td>
                                        <td>4,500 MXN</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-hd">
                                <h2><span>受験対策コース</span></h2>
                            </div>
                            <table>
                                <thead>
                                    <th>学年</th>
                                    <th>授業時間</th>
                                    <th>週1回（月4回）</th>
                                    <th>週2回（月8回）</th>
                                    <th>週3回（月12回）</th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>小学生（受験指導）</td>
                                        <td>50分</td>
                                        <td>3,545 MXN</td>
                                        <td>6,830 MXN</td>
                                        <td>10,080 MXN</td>
                                    </tr>
                                    <tr>
                                        <td>中学生（受験指導）</td>
                                        <td>50分</td>
                                        <td>3,680 MXN</td>
                                        <td>7,090 MXN</td>
                                        <td>10,270 MXN</td>
                                    </tr>
                                    <tr>
                                        <td>高学生（受験指導）</td>
                                        <td>50分</td>
                                        <td>3,930 MXN</td>
                                        <td>7,400 MXN</td>
                                        <td>10,270 MXN</td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="content-ft d-fl">
                                <p>90分間授業は途中に5分程度の休憩を含みます。<br>
                                    毎授業後、保護者の方にメールで授業報告をいたします。<br>
                                    授業料金は輸出扱いになるため、消費税(Sales Tax)はかかりません。
                                    </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();
