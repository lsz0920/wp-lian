<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>p</span>resent</h2>
                <h3 class="jp-ttl">ステップアップシート景品</h3>
            </div>
            <div class="sl-subpage-list">
                <ul>
                    <li><a href="#">模擬試験</a></li>
                    <li><a href="#">教育セミナートップ</a></li>
                    <li><a href="#">入試実績</a></li>
                    <li><a href="#">子供新聞</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </div>
        </div>
        <div class="sl-subpage-present-inn">
            <div class="breadcrumbs inner" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-present-inn-content-ttl">
                <div class="content-ttl">
                    <h2><span>ステップアップしてプレゼントをGET</span></h2>
                </div>
                <div class="sl-subpage-present-inn-content-box">
                    <div class="box-ttl">
                        <h2>1枚目のシート</h2>
                    </div>
                    <div class="box-data">
                        <div class="box-data-content">
                            <table>
                                <tr>
                                    <td>
                                        <article>
                                            <span>1</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present01/img01.png" alt="">
                                            </figure>
                                            <p>キュートフルノートセット</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>2</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present01/img02.png" alt="">
                                            </figure>
                                            <p>おかしえんぴつ(4本)</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>3</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present01/img03.png" alt="">
                                            </figure>
                                            <p>ライト付ボールペン</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>4</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present01/img04.png" alt="">
                                            </figure>
                                            <p>トミカ連絡ボード</p>
                                        </article>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <article>
                                            <span>5</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present01/img05.png" alt="">
                                            </figure>
                                            <p>リラックマちよがみ</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>6</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present01/img06.png" alt="">
                                            </figure>
                                            <p>スーパーマリオ定規</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>7</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present01/img07.png" alt="">
                                            </figure>
                                            <p>ワンピースクリアファイル</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>8</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present01/img08.png" alt="">
                                            </figure>
                                            <p>ポケモン消しゴム</p>
                                        </article>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <article>
                                            <span>9</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present01/img09.png" alt="">
                                            </figure>
                                            <p>ディズニー折り紙大小セット</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>10</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present01/img10.png" alt="">
                                            </figure>
                                            <p>ポケモン　ハンドタオル</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>11</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present01/img11.png" alt="">
                                            </figure>
                                            <p>スクール定規セット</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>12</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present01/img12.png" alt="">
                                            </figure>
                                            <p>国旗バンドエイド</p>
                                        </article>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-present-inn-content-box">
                    <div class="box-ttl">
                        <h2>2枚目のシート</h2>
                    </div>
                    <div class="box-data">
                        <div class="box-data-content">
                            <table>
                                <tr>
                                    <td>
                                        <article>
                                            <span>1</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present02/img01.png" alt="">
                                            </figure>
                                            <p>スヌーピーがま口 <br>
                                            （図柄は選べません）</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>2</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present02/img02.png" alt="">
                                            </figure>
                                            <p>デイズニ―文具セット</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>3</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present02/img03.png" alt="">
                                            </figure>
                                            <p>addidas定規</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>4</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present02/img04.png" alt="">
                                            </figure>
                                            <p>フラッシュヨーヨー</p>
                                        </article>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <article>
                                            <span>5</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present02/img05.png" alt="">
                                            </figure>
                                            <p>オレーズ　シールドシャープ</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>6</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present02/img06.png" alt="">
                                            </figure>
                                            <p>addidas ネームペン</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>7</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present02/img07.png" alt="">
                                            </figure>
                                            <p>addidasクリアファイル</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>8</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present02/img08.png" alt="">
                                            </figure>
                                            <p>ポケモン定規</p>
                                        </article>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <article>
                                            <span>9</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present02/img09.png" alt="">
                                            </figure>
                                            <p>Disneyシャープペン</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>10</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present02/img10.png" alt="">
                                            </figure>
                                            <p>スヌーピーシャープペン</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>11</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present02/img11.png" alt="">
                                            </figure>
                                            <p>ドラえもん文具セット</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>12</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present02/img12.png" alt="">
                                            </figure>
                                            <p>ポケモンケースセット</p>
                                        </article>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-present-inn-content-box">
                    <div class="box-ttl">
                        <h2>3枚目のシート</h2>
                    </div>
                    <div class="box-data">
                        <div class="box-data-content">
                            <table>
                                <tr>
                                    <td>
                                        <article>
                                            <span>1</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present03/img01.png" alt="">
                                            </figure>
                                            <p>おしゃれガールズペンポーチ</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>2</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present03/img02.png" alt="">
                                            </figure>
                                            <p>ケン玉</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>3</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present03/img03.png" alt="">
                                            </figure>
                                            <p>addidasボールペン <br>
                                            （色は選べません）</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>4</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present03/img04.png" alt="">
                                            </figure>
                                            <p>Pumaペンケース <br>
                                            （デザインは選べません）</p>
                                        </article>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <article>
                                            <span>5</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present03/img05.png" alt="">
                                            </figure>
                                            <p>Umboroシャープペン <br>
                                            （色は選べません）</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>6</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present03/img06.png" alt="">
                                            </figure>
                                            <p>ポケモンフェイスタオル <br>
                                            （デザインは選べません）</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>7</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present03/img07.png" alt="">
                                            </figure>
                                            <p>サンリオシャープペン <br>
                                            （色は選べません）</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>8</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present03/img08.png" alt="">
                                            </figure>
                                            <p>Puma2色ボールペン</p>
                                        </article>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <article>
                                            <span>9</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present03/img09.png" alt="">
                                            </figure>
                                            <p>adidas色鉛筆</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>10</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present03/img10.png" alt="">
                                            </figure>
                                            <p>モノ2way <br>
                                            （色は選べません）</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>11</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present03/img11.png" alt="">
                                            </figure>
                                            <p>すみっコぐらしミニポーチ <br>
                                            （デザインは選べません）</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>12</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present03/img12.png" alt="">
                                            </figure>
                                            <p>アニマルライト <br>
                                            （デザインは選べません）</p>
                                        </article>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-present-inn-content-box">
                    <div class="box-ttl">
                        <h2>4枚目のシート</h2>
                    </div>
                    <div class="box-data">
                        <div class="box-data-content">
                            <table>
                                <tr>
                                    <td>
                                        <article>
                                            <span>1</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present04/img01.png" alt="">
                                            </figure>
                                            <p>スヌーピートートバッグ</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>2</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present04/img02.png" alt="">
                                            </figure>
                                            <p>魔女の宅急便フィイスタオル</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>3</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present04/img03.png" alt="">
                                            </figure>
                                            <p>デズニーペンケース</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>4</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present04/img04.png" alt="">
                                            </figure>
                                            <p>マーベルペンセット</p>
                                        </article>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <article>
                                            <span>5</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present04/img05.png" alt="">
                                            </figure>
                                            <p>リラクマペンポーチ <br>
                                            （写真と異なる場合があります）</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>6</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present04/img06.png" alt="">
                                            </figure>
                                            <p>Lottaペンケース</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>7</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present04/img07.png" alt="">
                                            </figure>
                                            <p>マリオ12色色鉛筆</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>8</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present04/img08.png" alt="">
                                            </figure>
                                            <p>Dog Plazaペンケース</p>
                                        </article>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <article>
                                            <span>9</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present04/img09.png" alt="">
                                            </figure>
                                            <p>メッセンジャーバッグ <br>
                                            （デザインは選べません）</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>10</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present04/img10.png" alt="">
                                            </figure>
                                            <p>スヌーピーキルトバッグ</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>11</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present04/img11.png" alt="">
                                            </figure>
                                            <p>手動えんぴつ削り <br>
                                            （デザインは選べません）</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>12</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present04/img12.png" alt="">
                                            </figure>
                                            <p>ソフトカラー5色</p>
                                        </article>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <article>
                                            <span>13</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present04/img13.png" alt="">
                                            </figure>
                                            <p>マーベルペンセット</p>
                                        </article>
                                    </td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-present-inn-content-box">
                    <div class="box-ttl">
                        <h2>5枚目のシート</h2>
                    </div>
                    <div class="box-data">
                        <div class="box-data-content">
                            <table>
                                <tr>
                                    <td>
                                        <article>
                                            <span>1</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present05/img01.png" alt="">
                                            </figure>
                                            <p>リモコンルイーズカート</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>2</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present05/img02.png" alt="">
                                            </figure>
                                            <p>アニマル時計</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>3</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present05/img03.png" alt="">
                                            </figure>
                                            <p>鬼滅  箸＆ケースセット</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>4</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present05/img04.png" alt="">
                                            </figure>
                                            <p>Jet Stream</p>
                                        </article>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <article>
                                            <span>5</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present05/img05.png" alt="">
                                            </figure>
                                            <p>脳トレゲーム</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>6</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present05/img06.png" alt="">
                                            </figure>
                                            <p>Snoopy財布 <br>
                                            （デザインは選べません）</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>7</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present05/img07.png" alt="">
                                            </figure>
                                            <p>おしゃべりタブレット</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>8</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present05/img08.png" alt="">
                                            </figure>
                                            <p>キューブパズル</p>
                                        </article>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <article>
                                            <span>9</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present05/img09.png" alt="">
                                            </figure>
                                            <p>リラックマ腕時計 <br>
                                            （色は選べません）</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>10</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present05/img10.png" alt="">
                                            </figure>
                                            <p>すみっこぐらし腕時計 <br>
                                            （色は選べません）</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>11</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present05/img11.png" alt="">
                                            </figure>
                                            <p>鬼滅コップ</p>
                                        </article>
                                    </td>
                                    <td>
                                        <article>
                                            <span>12</span>
                                            <figure>
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/present/present05/img12.png" alt="">
                                            </figure>
                                            <p>ディズニー保冷温バック <br>
                                            （色は選べません）</p>
                                        </article>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-present-inn-content-info">
                    <p>
                        * 数に限りがある為、色、デザインを選べません。<br>
                        **景品の内容は予告なしで変更する事があります。<br>
                        景品は品切れになり次第、選択できなくなる場合があります。予めご了承下さい。<br>
                        景品については、今後も充実化を図ってまいります。
                    </p>
                </div>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();
