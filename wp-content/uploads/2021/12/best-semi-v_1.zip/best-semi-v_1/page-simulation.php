<?php
/**
 * @package v_1.0.1
 */

get_header();
?>

<main id="main" class="site-main">
    <div id="sl" class="sl-subpage">
        <div class="sl-subpage-mv">
            <div class="sl-subpage-ttl">
                <h2 class="eng-ttl"><span>s</span>imulation test</h2>
                <h3 class="jp-ttl">統一模試</h3>
            </div>
            <div class="sl-subpage-list">
                <ul>
                    <li><a href="#">模擬試験</a></li>
                    <li><a href="#">教育セミナートップ</a></li>
                    <li><a href="#">入試実績</a></li>
                    <li><a href="#">子供新聞</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </div>
        </div>
        <div class="sl-subpage-simulation-inn">
            <div class="breadcrumbs inner" typeof="BreadcrumbList" vocab="http://schema.org/">
                <?php if (function_exists('bcn_display')) {
                    bcn_display();
                }?>
            </div>
            <div class="sl-subpage-simulation-inn-content">
                <div class="sl-subpage-simulation-inn-content-list">
                    <div class="list-ttl">
                        <h2><span>帰国生受入校一覧</span></h2>
                    </div>
                </div>
                <div class="sl-subpage-simulation-inn-content-box">
                    <div class="box-ttl">
                        <h2>海外でも日本の小学生・中学生と同じ模擬試験が受けられます。</h2>
                    </div>
                    <div class="box-data">
                        <div class="box-data-content">
                            <table class="schedule-tbl">
                                <tbody>
                                    <tr>
                                        <th>対象学年</th>
                                        <td>小学4年生～中学3年生</td>
                                    </tr>
                                    <tr>
                                        <th>受験場所</th>
                                        <td>ご自宅で受験していいただきます。スカイプにて試験監督を行います。</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="box-data-ttl">
                            <h2><span>受験科目</span></h2>
                        </div>
                        <div class="box-data-content">
                            <table class="schedule-tbl">
                                <tbody>
                                    <tr>
                                        <th>小学生</th>
                                        <td>国語（40分）・算数（40分）</td>
                                    </tr>
                                    <tr>
                                        <th>中学1、2年生</th>
                                        <td>国語（40分）・数学（40分）・英語（40分）</td>
                                    </tr>
                                    <tr>
                                        <th>中学3年生</th>
                                        <td>国語（50分）・数学（50分）・英語（50分）</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="box-data-ttl">
                            <h2><span>成績表と分析内容</span></h2>
                        </div>
                        <div class="box-data-content">
                            <div class="content-list d-fl">
                                <div class="list-item">
                                    <article>
                                        <h3>小学生成績表</h3>
                                        <figure>
                                            <img src="<?php echo get_template_directory_uri(); ?>/img/simulation/img01.png" alt="" class="">
                                        </figure>
                                        <ul>
                                            <li>1.成績順位と偏差値</li>
                                            <li>2.受験者の分布</li>
                                            <li>3.偏差値の推移グラフ</li>
                                            <li>4.今回の成績結果総評</li>
                                            <li>5.出題項目別の成績</li>
                                        </ul>
                                    </article>
                                </div>
                                <div class="list-item">
                                    <article>
                                        <h3>教科別結果分析表</h3>
                                        <figure>
                                            <img src="<?php echo get_template_directory_uri(); ?>/img/simulation/img02.png" alt="" class="">
                                        </figure>
                                    </article>
                                </div>
                                <div class="list-item">
                                    <article>
                                        <h3>中学生成績表</h3>
                                        <figure>
                                            <img src="<?php echo get_template_directory_uri(); ?>/img/simulation/img03.png" alt="" class="">
                                        </figure>
                                        <ul>
                                            <li>1.成績順位と偏差値</li>
                                            <li>2.受験者の分布</li>
                                            <li>3.偏差値の推移グラフ</li>
                                            <li>4.今回の成績結果総評</li>
                                        </ul>
                                    </article>
                                </div>
                            </div>
                        </div>
                        <div class="box-data-ttl">
                            <h2><span>模試の受付から成績発表まで</span></h2>
                        </div>
                        <div class="box-data-content">
                            <div class="link-list d-fl">
                                <div class="link-btn d-fl">
                                    <h3><a>お申し込み</a></h3>
                                </div>
                                <div class="link-btn d-fl">
                                    <h3><a>お支払い</a></h3>
                                </div>
                                <div class="link-btn d-fl">
                                    <h3><a>模擬試験
                                        答案用紙
                                        到着</a></h3>
                                </div>
                                <div class="link-btn d-fl">
                                    <h3><a class="result">指定日 <br>
                                        模擬試験 <br>
                                        実施</a></h3>
                                </div>
                                <div class="link-btn d-fl">
                                    <h3><a>答案用紙
                                        郵送</a></h3>
                                </div>
                                <div class="link-btn d-fl">
                                    <h3><a>成績表 <br>
                                        到着</a></h3>
                                </div>
                            </div>
                            <div class="link-arrow d-fl">
                                <p>約40日</p>
                                <span></span>
                            </div>
                        </div>
                        <div class="box-data-ttl">
                            <h2><span>受験料</span></h2>
                        </div>
                        <div class="box-data-content">
                            <table class="schedule-tbl">
                                <tbody>
                                    <tr>
                                        <th>小学生</th>
                                        <td>$68</td>
                                    </tr>
                                    <tr>
                                        <th>中学生</th>
                                        <td>$73</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="sl-subpage-simulation-inn-content-box">
                    <div class="box-ttl">
                        <h2>スケジュール【2021年度】</h2>
                    </div>
                    <div class="box-data-content">
                            <table class="schedule-tbl">
                                <thead>
                                    <th></th>
                                    <th>受験日</th>
                                    <th>申込締切日</th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>第1回</td>
                                        <td>3月28日（日）</td>
                                        <td>3月19日（金）</td>
                                    </tr>
                                    <tr>
                                        <td>第2回</td>
                                        <td>8月22日（日）</td>
                                        <td>8月 6日（金）</td>
                                    </tr>
                                    <tr>
                                        <td>第3回</td>
                                        <td>1月9日（日）</td>
                                        <td>12月24日（金）</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                </div>
                <?php echo do_shortcode('[contact-form-7 id="212" title="申し込み"]'); ?>
            </div>
        </div>
        <?php get_template_part('common-banner');?>
    </div>
</main>
                <!-- #main -->

<?php
get_footer();
