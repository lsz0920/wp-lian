<?php
/**
 * @package v_1.0.1
 */

?>
</div>
    <!-- #content -->
	<footer id="footer" class="site-footer l-ft">
            <div class="ft-inn">
                <div class="ft-inn-logo">
                    <a href="">
                        <h1><img src="<?php echo get_template_directory_uri(); ?>/img/common/logo.svg" alt="logo"></h1>
                    </a>
                </div>
                <div class="ft-inn-nav d-fl">
                    <nav class="ft-nav-01">
                        <h2>スクールの特徴</h2>
                        <ul>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">マンツーマン授業</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">完全担任制</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">熱意あるプロ講師</a></li>
                        </ul>
                        <h2>コース紹介</h2>
                        <ul>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">読み書きをしっかり習得</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>guide/#notgood-jp">日本語が苦手なお子様</a></li>
                            <li><a href="">6歳未満のお子様</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>guide/#jlpt">日本語試験対策</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">帰国生受験対策</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">教科書に沿った学習</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">作文指導</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">帰国後の英語教育をご希望の方</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">授業料一覧表</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>free-trial/">無料体験レッスン</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">合格者実績</a></li>
                        </ul>
                    </nav>
                    <nav class="ft-nav-02">
                        <h2>受講スタイル</h2>
                        <ul>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">お申込みから入会・無料体験まで</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">授業を受けてみよう！</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>teachers">先生はどんな人？</a></li>
                        </ul>
                        <h2>帰国生受験情報</h2>
                        <ul>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">模擬試験を受けよう</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">帰国生受験を徹底分析</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>members">海外子女のための教育セミナー</a></li>
                        </ul>
                        <h2>教育活動</h2>
                        <ul>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">こども新聞</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">日本をもっと知ろう教室</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">生徒の作品</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">日本語教育コラム</a></li>
                        </ul>
                    </nav>
                    <nav class="ft-nav-03">
                        <h2>ベストゼミナールについて</h2>
                        <ul>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">会社概要</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>privacy-policy/">プライバシーポリシー</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>faq/">よくある質問</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>course/">ユーザーレビュー</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>">企業の皆さまへ</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>news">お知らせ</a></li>
                            <li><a href="<?php echo esc_html( home_url('/') ) ?>contact">お問合せ</a></li>
                        </ul>
                        <div class="fb-banner">
                            <img src="<?php echo get_template_directory_uri(); ?>/img/common/fb-bnr.png" alt="">
                            <a href=""><img src="<?php echo get_template_directory_uri(); ?>/img/common/fb-bnr-01.png" alt=""></a>
                        </div>
                        <div class="entry-banner">
                            <a href=""><img src="<?php echo get_template_directory_uri(); ?>/img/common/entry-bnr.png" alt=""></a>
                        </div>
                    </nav>
                </div>
            </div>
            <div class="ft-copy">
                <div class="ft-copy-logo">
                    <img src="<?php echo get_template_directory_uri(); ?>/img/common/ft-logo.svg" alt="">
                </div>
                <p>Copyright© Best Seminar & Five Start Inc. All Rights Reserved.</p>
            </div>
            <div class="top-btn">
                <a href="" rel="alternate"><img src="<?php echo get_template_directory_uri(); ?>/img/common/top-btn.svg" alt="top"></a>
            </div>
        </footer><!-- #footer -->
	</div><!-- #primary -->
</div><!-- #page -->
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.6.1/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.6.1/ScrollTrigger.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/js/src/common.min.js?v=1.2.0.<?=rand()?>"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/js/src/app.min.js?v=1.2.0.<?=rand()?>"></script>
<?php wp_footer(); ?>

</body>
</html>
